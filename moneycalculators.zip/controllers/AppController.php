<?php

class AppController extends Controller
{
    public function __construct()
    {
        Loader::model('AppModel');
        parent::__construct();
    }

    public static function home($params)
    {
        $model = new AppModel();
        Loader::view('templates/index', array('viewName' => 'home'));
    }

    public static function emiCalc($params)
    {
        Loader::view('emiCalc/index');
    }

    public static function ifscCodeFinder($params)
    {
        Loader::view('ifscCodeFinder/index');
    }

    public static function fdCalc($params)
    {
        Loader::view('templates/index', array('viewName' => 'fdCalc'));
    }

    public static function customDutyCalc($params)
    {
        Loader::view('templates/index', array('viewName' => 'customDutyCalc'));
    }

    public static function gstCalc($params)
    {
        Loader::view('templates/index', array('viewName' => 'gstCalc'));
    }

}