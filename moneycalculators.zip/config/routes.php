<?php
//Regex
Router::get('/', 'AppController', 'emiCalc');
Router::get('/emi-calculator', 'AppController', 'emiCalc');
Router::get('/ifsc-code-finder', 'AppController', 'ifscCodeFinder');
Router::get('/fd-calculator', 'AppController', 'fdCalc');
Router::get('/custom-duty-calculator', 'AppController', 'customDutyCalc');
Router::get('/gst-calculator', 'AppController', 'gstCalc');


