<?php

/**
 * Classe controller base do sistema
 */
abstract class Controller
{
    /**
     * Só pra mostrar q eu sei mesmo
     */
    public function __construct()
    {
    }
}