<div class="navbar navbar-inverse navbar-fixed-top">
    <div class="navbar-inner">
        <div class="container">
            <div class="col-md-3" style="color: #fff;font-size: 24px;">
            <a href="/" class="header-logo">
                MoneyCalculators
            </a>
            </div>
            <div class="col-md-9" style="float: right; margin-right: 0px; margin-left: 0px;">
                <div class="nav-collapse">
                    <ul class="nav" style="margin-right: -12px;display: -webkit-box; text-align: right; float: right;">
                        <li class=""><a href="/emi-calculator/" style="color: #fff; text-decoration: none;">EMI Calculator</a></li>
                        <li class=""><a href="/blogs/" style="color: #fff; text-decoration: none;">Blogs</a></li>
                        <li class=""><a href="/blogs/contact-us/" style="color: #fff; text-decoration: none;">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>