<div class="float-right">
    <a href="https://twitter.com/share?url=https://<?=$_SERVER['HTTP_HOST']?><?=$_SERVER['REQUEST_URI']?>"
    title="Twitter" class="btn btn-twitter btn-lg" target="_blank">
    <i class="fa fa-twitter fa-fw"></i> Share on Twitter</a>
</div>