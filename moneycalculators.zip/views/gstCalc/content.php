<div class="container pb-4">
    <div class="row mt-3">
        <div class="col-md-12">
            <h1>Online GST Calculator</h1>
            <p class="mt-3">Use this GST calculator for ...</p>
        </div>
    </div>
</div>