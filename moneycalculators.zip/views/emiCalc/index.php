<?php 
   $arrDefined = array(
   	"loan_amount_value" => 5000000, "loan_amount_min" => 100000, "loan_amount_max" => 20000000, 
   	"interest_rate_value" => 9, "interest_rate_min" => 1, "interest_rate_max" => 20, 
   	"loan_tenure_value" => 20, "loan_tenure_min" => 1, "loan_tenure_max" => 30
   );
   ?>
   <style>
	   #interest_table th{width: 110px;}
	   #interest_table td{width: 110px;}
   </style>
<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
      <script src="https://www.gstatic.com/charts/loader.js"></script>
      <script src="<?=URL_BASE?>views/emiCalc/calculators.js"></script>
      <link href="<?=URL_BASE?>views/emiCalc/static/css/calculator_css.css" rel="stylesheet" />
   </head>
   <body>
      <div id="overlay" style="display:none;">
         <div class="spinner"></div>
         <br/>
         Pocessing...
      </div>
      <!-- Button trigger modal -->
      <button type="button" class="btn btn-primary hide" id="show-alert-message" data-toggle="modal" data-target="#exampleModalCenter">
      </button>
      <!-- Modal -->
      <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
         <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
               <div class="modal-header" style="font-size: 18px;font-weight: 700;">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true" style="font-size: 32px;">&times;</span>
				  </button>
				  Impact of the change(s)
               </div>
               <div class="modal-body">
                  <div class="alert alert-danger" id="warning-message" role="alert" style="display: none;"></div>
                  <div class="alert alert-success" id="success-message" role="alert" style="display: none;"></div>
               </div>
            </div>
         </div>
      </div>
      <?php include $_SERVER['DOCUMENT_ROOT'].'/views/templates/leftNav2.php';?>
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <ul class="nav nav-tabs loan-type">
                  <li class="active"><a data-toggle="tab" href="#home" data-id="home">Home Loan</a></li>
                  <li><a data-toggle="tab" href="#menu1" data-id="menu1">Personal Loan</a></li>
                  <li><a data-toggle="tab" href="#menu2" data-id="menu2">Car Loan</a></li>
                  <li><a data-toggle="tab" href="#menu3" data-id="menu3">Compare Loans</a></li>
               </ul>
            </div>
            <div class="col-md-12">
               <div class="tab-content">
                  <div id="home" class="tab-pane fade in active">
                     <div class="row">
                        <form class="form-horizontal" id="submitData">
                           <div class="col-md-8" style="padding-right: 50px; padding-top: 30px;">
                              <div class="row">
                                 <div class="col-md-4">
                                    <div class="row">
                                       <div class="col-md-12" style="padding-bottom: 10px;">
                                          Loan Amount
                                       </div>
                                       <div class="col-md-12" style="padding-bottom: 20px;">
                                          <div class="form-row">
                                             <div class="input-group">
                                                <span class="input-group-addon" style="font-size: 24px; border-radius: 10px 0px 0px 10px;background-color: #0f3b68; color: #fff;">₹ </span>
                                                <input type="number" value="<?=$arrDefined['loan_amount_value']?>"  class="form-control currency" id="principal-show" name="principal-show" style="height: 38px; border-radius: 0px 10px 10px 0px;"/>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-md-12">
                                          <input type="range" step="50000" min="<?=$arrDefined['loan_amount_min']?>" max="<?=$arrDefined['loan_amount_max']?>" value="<?=$arrDefined['loan_amount_value']?>" class="slider" id="principal" name="principal">
                                          <p style="padding-top: 10px; color: #7d7b7c;">
                                             <span id="principal-word">1L</span><span style="float: right;">200L</span>
                                          </p>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="row">
                                       <div class="col-md-12" style="padding-bottom: 10px;">
                                          Interest Rate
                                       </div>
                                       <div class="col-md-12" style="padding-bottom: 20px;">
                                          <div class="form-row">
                                             <div class="input-group">
                                                <span class="input-group-addon" style=" font-size: 24px; border-radius: 10px 0px 0px 10px;background-color: #0f3b68; color: #fff;">%</span>
                                                <input type="number" value="<?=$arrDefined['interest_rate_value']?>" class="form-control currency" id="rate-show" name="rate-show" style="height: 38px; border-radius: 0px 10px 10px 0px;"/>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-md-12">
                                          <input type="range" step="0.5" min="<?=$arrDefined['interest_rate_min']?>" max="<?=$arrDefined['interest_rate_max']?>" value="<?=$arrDefined['interest_rate_value']?>" class="slider" id="rate" name="rate">
                                          <p style="padding-top: 10px; color: #7d7b7c;">
                                             <span id="rate-word">1%</span><span style="float: right;">  20%</span>
                                          </p>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="row">
                                       <div class="col-md-6" style="padding: 0px 0px 15px 15px;">
                                          Tenure
                                       </div>
                                       <div class="col-md-6" style="padding-bottom: 10px;">
                                          <div class="btn-group colors" data-toggle="buttons" style="margin-top: -18px;">
                                             <label class="btn btn-primary active">
                                             <input type="radio" name="tenure_options" id="tenure_options_1" value="1" autocomplete="off" checked> Yr
                                             </label>
                                             <label class="btn btn-primary">
                                             <input type="radio" name="tenure_options" id="tenure_options_2" value="2" autocomplete="off"> Mo
                                             </label>
                                          </div>
                                       </div>
                                       <div class="col-md-12" style="padding-bottom: 20px;">
                                          <div class="form-row">
                                             <div class="input-group" style="width: 100%;">
                                                <input type="number" value="<?=$arrDefined['loan_tenure_value']?>" class="form-control currency" id="time_months-show" name="time_months-show" style="height: 38px; border-radius: 10px 10px 10px 10px;"/>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-md-12">
                                          <input type="range" min="<?=$arrDefined['loan_tenure_min']?>" max="<?=$arrDefined['loan_tenure_max']?>" value="<?=$arrDefined['loan_tenure_value']?>" class="slider" id="time_months_input" name="time_months_input">
                                          <p style="padding-top: 10px; color: #7d7b7c;">
                                             <span id="time_months-word"></span><span style="float: right;" id="Tenure-word"> 30</span>
                                          </p>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-md-12">
                                          <input type="hidden" id="time_months" name="time_months" value="<?=($arrDefined['loan_tenure_value'] * 12)?>">
                                          <input type="hidden" id="start_emi_time" name="start_emi_time" value="<?php echo date('m/d/Y')?>">
                                          <input type="hidden" id="emi" name="emi" value="">
                                          <input type="hidden" id="oldMonth" name="oldMonth" value="">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>

						   
                           <div class="col-md-4" style="padding-left: 20px;margin-top: 10px;">
                              <div class="row" style="font-size: 16px; padding-top: 4px; padding-bottom: 4px;">
                                 <span class="col-md-8">Monthly EMI</span>
                                 <span class="col-md-4" style="font-weight: 700; color: #0f3b68; float: right; text-align: right;">₹ <span class="" id="label1"></span></span>
                              </div>
                              <div class="row" style="font-size: 16px;padding-top: 4px; padding-bottom: 4px;">
                                 <span class="col-md-8">Total Interest Payable</span>
                                 <span class="col-md-4" style="font-weight: 700; color: #0f3b68; float: right; text-align: right;">₹ <span class="" id="label2"></span></span>
                                 <span class="hide" id="first-principal-changes"></span>
                              </div>
                              <div class="row" style="padding-top: 6px;font-size: 16px; margin-bottom: 16px;">
                                 <span class="col-md-6" style="float: left;">
                                    Total Payment<br>(Principal + Interest)
                                 </span>
                                 <span class="col-md-6" style="font-weight: 700; color: #0f3b68; float: right; text-align: right;">₹ <span class="" id="label7"></span></span>
                              </div>
                              <div class="progress">
                                 <div id="pei-progress" class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
                                 </div>
                              </div>
                              <div class="row">
                                 <span class="col-md-7">
                                    <span style="width: 37px; height: 31px; background-color: #0f3b68;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    <span>Principal Loan Amount</span>
                                 </span>
                                 <span class="col-md-5" style="text-align: center;">
                                    <span style="width: 37px; height: 31px; background-color: #7d7b7c;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                    <span>Total Interest</span>
                                 </span>
                              </div>
                           </div>
                           <button class="btn btn-primary emi-calculator hide" id="submit_btn" type="submit" onclick="return false;">Calculate</button>
                        </form>
                     </div>
                  </div>
                  <div id="menu1" class="tab-pane fade">
                  </div>
                  <div id="menu2" class="tab-pane fade">
                  </div>
                  <div id="menu3" class="tab-pane fade">
                  </div>
               </div>
            </div>
         </div>
         <hr/>
         <div class="row no-compare">
            <div class="col-md-12">
               <div id="breakup_details">
                  <h3 style="margin-top: 0px; margin-bottom: 20px;">Know the impact of change in EMI, rate of interest or prepayments on the total outstanding loan</h3>
                  <div class="row" style="margin-left: 0px; margin-right: 0px;">
                     <div class="col-md-6" style="background-color: #7d7b7c;">
                        <h3 style="text-align: center;color: #fff;padding-bottom: 10px;margin-top: 8px;margin-bottom: 0px;">Schedule showing EMI payments starting from</h3>
                     </div>
                     <div class="col-md-6" style="background-color: #7d7b7c;">
                        <div class="form-group" style="padding-top: 5px; margin-bottom: 5px;">
                           <div class='input-group date' id='datetimepicker1'>
                              <input type='text' class="form-control monthPicker" id="start_emi_month" style="width: 48%; float: right;" value="<?php echo date('F Y')?>"/>
                              <span class="input-group-addon">
                              	<span class="glyphicon glyphicon-calendar"></span>
                              </span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <table class="table table-hover table-bordered table-condensed" id="interest_table">
                     <thead>
                        <tr>
                           <th>EMI Month</th>
                           <th>Interest (INR)</th>
                           <th>Principal (INR)</th>
                           <th>Balance Principal (INR)</th>
                           <th>ROI (%)</th>
                           <th>EMI (INR)</th>
                           <th>New ROI</th>
                           <th>Pre-Payment</th>
                           <th>New EMI</th>
                        </tr>
                     </thead>
                     <tbody>
                     </tbody>
                  </table>
                  <div id="feature_buttons" align="right">
                  </div>
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-md-12">
               <h3 style="color: #8bce00;padding-bottom: 20px;">How to Use EMI Calculator?</h3>
               <p>With colorful charts and instant results, our EMI Calculator is easy to use, intuitive to understand and is quick to perform. You can calculate EMI for home loan, car loan, personal loan, education loan or any other fully amortizing loan using this calculate</p>
               <p style="font-weight: 700;">Enter the following information in the EMI Calculator:</p>
               <ul>
                  <li>Principal loan amount you wish to avail(rupees)</li>
                  <li>Loan term (month or years)</li>
                  <li>Rate of interest (percentage)</li>
                  <li>EMI in advance OR EMI in arrears(for can loan only)</li>
                  <li>Use the slider to adjust the values in the EMI calculator form. If you need to enter more precise values, you can type the values directly in the relevant boxes provide above. AS soon as the values are changed using the slider(or hit 'tab' key after entering the values directly in the input fields), EMI calculator will re-calculate your monthly payment (EMI) amount.</li>
               </ul>
               <p>After the calculater table shows year wise principal or mortgage amount in absolute number and percentage, interest paid and balance principal or mortgage. For better financial saving and planning, we have given options to change EMI, interest rate and pre-payment of principal amount in any of the month (s) during tenure of loan / mortgage term in last three columns (user need to click '+' against any year to expand).
                  Once information is filled in any of the last thee columns a popup will show you saving in interest and tenure over the information originally filled in the calculator.   
               </p>
            </div>
         </div>
         <hr/>
         <div class="row">
            <div class="col-md-12">
               <!-- <h2 style="color: #8bce00;padding-bottom: 20px;">Recent Blogs</h2> -->
            </div>
         </div>
         <hr />
      </div>
      <!-- /container -->
      <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <script>
         $(document).ready(function(){
         
         	var html = $("#home").html();
         
         	$("#menu1").html('');
         	$("#menu2").html('');
         	$("#menu3").html('');
         
         	
         	
         	$(".input-group-addon").click(function(){
         		setTimeout(function(){
         			$("#start_emi_month").focus();
         		}, 300);
         	});
         
         	$("form input:radio").change(function () {
         		switch($(this).val()){
         			case "1":
         				var time_months_input = Math.ceil($("input[name=time_months_input]").val() / 12);
         				
         				$("input[name=time_months]").val(time_months_input * 12);
         				$("#time_months-word").html("<?=$arrDefined['loan_tenure_min']?>");
         				$("#time_months-show").val(time_months_input);
         
         				
         				$("#Tenure-word").html($("input[name=time_months_input]").attr("max") / 12);
         				$("input[name=time_months_input]").attr("max", $("input[name=time_months_input]").attr("max") / 12);
         
         				$("input[name=time_months_input]").val(time_months_input);
         				$("#submit_btn").click();
         			break;
         			case "2":
         				var time_months_input = Math.ceil($("input[name=time_months_input]").val() * 12);
         				$("input[name=time_months]").val(time_months_input);
         				$("#time_months-word").html("<?=$arrDefined['loan_tenure_min']?>");
         				$("#time_months-show").val(time_months_input);
         				$("#Tenure-word").html($("input[name=time_months_input]").attr("max") * 12);
         				$("input[name=time_months_input]").attr("max", $("input[name=time_months_input]").attr("max") * 12);
         
         				$("input[name=time_months_input]").val(time_months_input);
         				$("#submit_btn").click();
         			break;
         		}
         	});
         
         	
         	$("li a").click(function(){
         		
         		$("#home").html('');
         		$("#menu1").html('');
         		$("#menu2").html('');
         		$("#menu3").html('');
         		
         		if($(this).attr('data-id') == "menu3"){
         			$(".no-compare").hide();
         			$("#"+$(this).attr('data-id')).append(html);
         			$("#"+$(this).attr('data-id')).append(html);
         			$("#"+$(this).attr('data-id')).append(html);
         			//$("#submit_btn").click();
         		}else{
         			$(".no-compare").show();
         			$("#"+$(this).attr('data-id')).html(html);
         			$("#submit_btn").click();
         		}
         		$( ".emi-calculator" ).each(function( i ) {
         			$(this).parents('form').find('#submit_btn').click();
         		});
         		var a = [''];
         		for(var i=1; i<=100; i++){
         			a.push(i+' ');
         		}
         		var b = ['', '', '20','30','40','50', '60','70','80','90'];
         
         		function inWords (num) {
         			if ((num = num.toString()).length > 9) return 'overflow';
         			n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
         			if (!n) return; var str = '';
         			str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'Crore ' : '';
         			str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'Lac ' : '';
         			str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'Thousand ' : '';
         			str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'Hundred ' : '';
         			str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'only ' : '';
         			return str;
         		}
         		function numberWithCommas(x) {
         			return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
         		}
         
         		
         		
         		$("input[name=principal]").on('input', function() {
         			
         			$(this).parent().parent().find("input[type=number]").val($(this).val());
         		});
         		$("input[name=principal]").on('mouseup', function() {
         			changeSecond();
         			//alert($(this).parents('form').find('input[name="principal"]').val());
         			$(this).parents('form').find('#submit_btn').click();
         			//$("#submit_btn").click();
         		});
         		$("input[name=principal-show]").on('input', function() {
         			if(this.value >= 100000){
         				$("#warning-message").hide();
         				$(this).parent().parent().parent().parent().find("input[type=range]").val($(this).val());
         				//$("#submit_btn").click();
         				$(this).parents('form').find('#submit_btn').click();
         				changeSecond();
         			}else{
         				$("#warning-message").html("Minimum loan amount should be 100000");
         				$("#warning-message").show();
         			}
         		});
         
         		function emi_calculator(p, r, t) { 
         			// one month interest 
         			r = r / (12 * 100); 
         			
         			// one month period 
         			t = t * 12;  
         			
         			var emi = (p * r * Math.pow(1 + r, t)) / (Math.pow(1 + r, t) - 1); 
         			
         			return (emi); 
         		} 
         
         		function changeSecond(){
         			
         			var principal = 100000; // 2 lakh 50 thousands as principal
         			var rate = 1; // 9.25 as Rate of interest per annum
         			var time = 20; // 2 years as Repayment period
         			var emi = emi_calculator(principal, rate, time);
         			
         		}
         		
         		
         		$("input[name=rate]").on('input', function() {
         			$(this).parent().parent().find("input[type=number]").val($(this).val());
         		});
         		$("input[name=rate]").on('mouseup', function() {
         			$(this).parents('form').find('#submit_btn').click();
         		});
         		$("input[name=rate-show]").on('input', function() {
         			if(this.value <= 20){
         				$("#warning-message").hide();
         				$(this).parent().parent().parent().parent().find("input[type=range]").val($(this).val());
         				$(this).parents('form').find('#submit_btn').click();
         			}else{
         				$("#warning-message").html("Rate should be between 1 to 20");
         				$("#warning-message").show();
         			}
         		});
         
         		
         		$("input[name=time_months_input]").on('input', function() {
         			$(this).parent().parent().find("input[type=number]").val($(this).val());
         			$(this).parents('form').find('#submit_btn').click();
         		});
         		$("input[name=time_months_input]").on('mouseup', function() {
         			
         			if($(this).parents('form').find('input[name=tenure_options]:checked').val() == 1){
         				$(this).parents('form').find('input[name=time_months]').val($(this).parents('form').find('input[name=time_months-show]').val() * 12);
         			}else{
         				$(this).parents('form').find('input[name=time_months]').val($(this).parents('form').find('input[name=time_months-show]').val());
         			}
         			$(this).parents('form').find('#submit_btn').click();
         			
         		});
         
         		$("input[name=time_months-show]").on('input', function() {
         			
         			if($(this).parents('form').find('input[name=tenure_options]:checked').val() == 1){
         				if($(this).val() > 0 && $(this).val() <= 30){
         					$(this).parents('form').find('input[name=time_months]').val($(this).parents('form').find('input[name=time_months-show]').val() * 12);
         					$("#warning-message").hide();
         					$(this).parents('form').find('#time_months_input').innerHTML = $(this).val();
         					$(this).parents('form').find('#submit_btn').click();
         
         					
         				}else{
         					$("#warning-message").html("Year should be between 1 to 30");
         					$("#warning-message").show();
         				}
         			}else{
         				if(this.value > 0 && this.value <= 360){
         					$("#warning-message").hide();
         					$(this).parents('form').find('input[name=time_months]').val($(this).parents('form').find('input[name=time_months-show]').val());
         					$(this).parents('form').find('#time_months_input').innerHTML = $(this).val();
         					$(this).parents('form').find('#submit_btn').click();
         				}else{
         					$("#warning-message").html("Month should be between 1 to 360");
         					$("#warning-message").show();
         				}
         			}
         		});
         		
         
         		$("form input:radio").change(function () {
         			
         			switch($(this).val()){
         				case "1":
         					var time_months_input = Math.ceil($("input[name=time_months_input]").val() / 12);
         					
         					$("input[name=time_months]").val(time_months_input * 12);
         					$("#time_months-word").html("<?=$arrDefined['loan_tenure_min']?>");
         					$("#time_months-show").val(time_months_input);
         
         					
         					$("#Tenure-word").html($("input[name=time_months_input]").attr("max") / 12);
         					$("input[name=time_months_input]").attr("max", $("input[name=time_months_input]").attr("max") / 12);
         
         					$("input[name=time_months_input]").val(time_months_input);
         					$("#submit_btn").click();
         				break;
         				case "2":
         					var time_months_input = Math.ceil($("input[name=time_months_input]").val() * 12);
         					$("input[name=time_months]").val(time_months_input);
         					$("#time_months-word").html("<?=$arrDefined['loan_tenure_min']?>");
         					$("#time_months-show").val(time_months_input);
         					$("#Tenure-word").html($("input[name=time_months_input]").attr("max") * 12);
         					$("input[name=time_months_input]").attr("max", $("input[name=time_months_input]").attr("max") * 12);
         
         					$("input[name=time_months_input]").val(time_months_input);
         					$("#submit_btn").click();
         				break;
         			}
         		});
         
         		$(".input-group-addon").click(function(){
         			setTimeout(function(){
         				$("#start_emi_month").focus();
         			}, 300);
         		});
         	})
         
         	$("#submit_btn").click();
         	$( "#start_emi_month" ).datepicker({
         			dateFormat: 'MM yy',
         			changeMonth: true,
         			changeYear: true,
         			showButtonPanel: true,
         			onClose: function(dateText, inst) {
         				
         				var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
         				var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
         				$(this).val($.datepicker.formatDate('MM yy', new Date(year, month, 1)));
         				var currentDate = new Date($("input[name=start_emi_time]").val());
         				
         				if(currentDate.getMonth() != month || currentDate.getFullYear() != year){
         					$("input[name=start_emi_time]").val((parseInt(month) + 1)+"/01/"+year);
         					
         					$("#submit_btn").click();
         				}
         			}
         	});
         
         	$(".monthPicker").focus(function () {
         		$(".ui-datepicker-calendar").hide();
         		$("#ui-datepicker-div").position({
         			my: "center top",
         			at: "center bottom",
         			of: $(this)
         		});
         	});
         
         	$(document).on('focus','input[name=new_rate_of_interest]',function(){
				$(this).attr('oldValue', $(this).val());
         	});
         	$(document).on('focus','input[name=pre_payment]',function(){
				$(this).attr('oldValue', $(this).val());
         	});
         	$(document).on('focus','input[name=new_emi]',function(){
				$(this).attr('oldValue', $(this).val());
         	});
         
         	
         	
         	
         });
      </script>
      <script>
         // in word
         
         var a = [''];
         for(var i=1; i<=100; i++){
         	a.push(i+' ');
         }
         var b = ['', '', '20','30','40','50', '60','70','80','90'];
         
         function inWords (num) {
         	if ((num = num.toString()).length > 9) return 'overflow';
         	n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
         	if (!n) return; var str = '';
         	str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'Crore ' : '';
         	str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'Lac ' : '';
         	str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'Thousand ' : '';
         	str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'Hundred ' : '';
         	str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'only ' : '';
         	return str;
         }
         function numberWithCommas(x) {
         	return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
         }
         // priciple
         var slider_1 = document.getElementById("principal");
         var output_1 = document.getElementById("principal-show");
         output_1.value = (slider_1.value);
         //document.getElementById("principal-word").innerHTML = inWords(slider_1.value);
         
         slider_1.oninput = function() {
         	output_1.value = this.value;
         }
         slider_1.onmouseup= function(){
         	$("#submit_btn").click();
         }
         
         output_1.oninput = function() {
         	if(this.value >= 100000){
         		$("#warning-message").hide();
         		slider_1.value = this.value;
         		$("#submit_btn").click();
         	}else{
         		$("#warning-message").html("Minimum loan amount should be 100000");
         		$("#warning-message").show();
         	}
         	
         }
         
         // rate
         var slider_2 = document.getElementById("rate");
         var output_2 = document.getElementById("rate-show");
         output_2.value = slider_2.value;
         //document.getElementById("rate-word").innerHTML = slider_2.value;
         
         slider_2.oninput = function() {
         	output_2.value = this.value;
         }
         slider_2.onmouseup= function(){
         	$("#submit_btn").click();
         }
         output_2.oninput = function() {
         	if(this.value <= 20){
         		$("#warning-message").hide();
         		slider_2.value = this.value;
         		
         		$("#submit_btn").click();
         	}else{
         		$("#warning-message").html("Rate should be between 1 to 20");
         		$("#warning-message").show();
         	}
         	
         }
         
         // loan tenure
         var slider_3 = document.getElementById("time_months_input");
         var output_3 = document.getElementById("time_months-show");
         output_3.value = slider_3.value;
         document.getElementById("time_months-word").innerHTML = "<?=$arrDefined['loan_tenure_min']?>";
         
         slider_3.oninput = function() {
         	output_3.value = this.value;
         }
         slider_3.onmouseup= function(){
         	if($("input[name=tenure_options]:checked").val() == 1){
         		$("input[name=time_months]").val(slider_3.value * 12);
         	}else{
         		$("input[name=time_months]").val(slider_3.value);
         	}
         	
         	$("#submit_btn").click();
         }
         
         output_3.oninput = function() {
         	
         	if($("input[name=tenure_options]:checked").val() == 1){
         		if(this.value > 0 && this.value <= 30){
         			$("#warning-message").hide();
         			slider_3.value = this.value;
         			$("input[name=time_months]").val(slider_3.value * 12);
         			$("#submit_btn").click();
         		}else{
         			$("#warning-message").html("Year should be between 1 to 30");
         			$("#warning-message").show();
         		}
         	}else{
         		if(this.value > 0 && this.value <= 360){
         			$("#warning-message").hide();
         			slider_3.value = this.value;
         			$("input[name=time_months]").val(slider_3.value);
         			$("#submit_btn").click();
         		}else{
         			$("#warning-message").html("Month should be between 1 to 360");
         			$("#warning-message").show();
         		}
         	}
         	
         }
         
      </script>
   </body>
</html>