function isNumber(n) {
    return typeof n == 'number' && !isNaN(n - n);
}

function addCommaOnly(x) {
    x = parseFloat(x)
    if (isNumber(x)) {
        sign = 1
        if (x < 0) {
            sign = -1
            x *= sign
        }
        f_str = sign == 1 ? "" : "-"
        var parts = x.toString().split(".");
        if (parts[0].length > 3)
            parts[0] = parts[0].slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ",") + "," + parts[0].slice(-3)
        f_str += parts.join(".");
        return (f_str)
    } else return x.toString()
}

function removeCommas(str) {
    while (str.search(",") >= 0) {
        str = (str + "").replace(',', '');
    }
    return parseFloat(str).toFixed(2);
};

function addCommaCurrency(x) {

    var formatter = new Intl.NumberFormat('en-IN', {
        minimumFractionDigits: 0,
    });
    return formatter.format(Math.trunc(x));

}

function convertToNum(n) {
    if (!isNumber(parseFloat(n))) return 0
    else return n
}
$(document).ready(function() {
    $(function() {
        $("#principal").focus();
    });

    function annualRecurringDepositCalculator(principal, rate, time_years, time_months, frequency) {
        months_in_year = 12.0
        sum = 0
        total_p = 0
        p = parseFloat(principal)
        r = parseFloat(rate)
        n_months = parseFloat(time_months)
        if (isNaN(n_months - n_months)) n_months = 0
        n_years = parseFloat(time_years)
        if (isNaN(n_years - n_years)) n_years = 0
        n = n_years + n_months / months_in_year
        n_floor = Math.floor(n)
        n_months = Math.floor((n - n_floor) * months_in_year)
        n = n_floor + n_months / months_in_year
        n_ceil = Math.ceil(n)
        f = parseInt(frequency)
        delta = months_in_year / f
        for (var i = n_ceil; i > 0; i--) {
            t = p * Math.pow((1 + ((r / delta) / 100.0)), (n - n_ceil + i) * delta)
            sum += t
            total_p += p
            row = '<tr><td>' + addCommaCurrency(p) + '</td><td>' + (n_ceil - i) + '</td><td>' + n_floor + "." + n_months +
                '</td><td>' + (i + n_floor - n_ceil) + "." + n_months + '</td><td>' + addCommaCurrency(t) +
                '</td><td>' + addCommaCurrency(sum) + '</td></tr>'
            $('#interest_table > tbody:last').append(row);
        };
        row = '<tr class="success"><td colspan="5" class="cellTextRight">Total Maturity Amount:</td><td class="textMajor">' + addCommaCurrency(sum) + '</td></tr>'
        $('#interest_table > tbody:last').append(row);

        $("#breakup_details").show()
        $(".breakup_details").show()

        $("#label4").text(addCommaCurrency(p) + "")
        $("#label5").text(r + "%")
        $("#label6").text("Time: " + n_floor + " Years and " + n_months + " Months")
        $("#label1").text(addCommaCurrency(sum) + "")
        $("input[name=emi]").val(sum)
        $("#label2").text(addCommaCurrency((sum - total_p)) + "")
        $("#label3").text(addCommaCurrency((total_p)) + "")
    }

    $("#submit_btn.annual-recurring").click(function() {
        $("#interest_table").find("tr:gt(0)").remove();
        principal = $("#principal").val()
        rate = $("#rate").val()
        time_years = $("#time_years").val()
        time_months = $("#time_months").val()
        frequency = $("input:radio[name=compoundperiod]:checked").val()
        annualRecurringDepositCalculator(principal, rate, time_years, time_months, frequency)
    });

    function monthlyRecurringDepositCalculator(principal, rate, time_years, time_months, frequency) {
        months_in_year = 12.0
        sum = 0
        total_p = 0
        p = parseFloat(principal)
        r = parseFloat(rate)

        n_months = parseFloat(time_months)
        if (isNaN(n_months - n_months)) n_months = 0
        n_years = parseFloat(time_years)
        if (isNaN(n_years - n_years)) n_years = 0
        n = Math.floor(n_years * months_in_year + n_months) //months
        n_years = Math.floor(n_floor / months_in_year)
        n_months = n % months_in_year

        f = parseInt(frequency)
        delta = months_in_year / f
        for (var i = n; i > 0; i--) {
            t = p * Math.pow((1 + ((r / delta) / 100.0)), (i) * (delta / months_in_year))
            sum += t
            total_p += p
            row = '<tr><td>' + addCommaCurrency(p) + '</td><td>' + (n - i) + '</td><td>' + n + '</td><td>' + parseFloat((i + n - n_ceil)).toString() + '</td><td>' + addCommaCurrency(t) + '</td><td>' + addCommaCurrency(sum) + '</td></tr>'
            $('#interest_table > tbody:last').append(row);
        };
        row = '<tr class="success"><td colspan="5" class="cellTextRight">Total Maturity Amount:</td><td class="textMajor">' + addCommaCurrency(sum) + '</td></tr>'
        $('#interest_table > tbody:last').append(row);

        $("#breakup_details").show()
        $(".breakup_details").show()
        $("#label4").text(ddCommaCurrency(p) + "")
        $("#label5").text(r + "%")
        $("#label6").text("Time: " + n_floor + " Years and " + n_months + " Months")
        $("#label1").text(addCommaCurrency(sum) + "")
        $("input[name=emi]").val(sum)
        $("#label2").text(addCommaCurrency((sum - total_p)) + "")
        $("#label3").text(addCommaCurrency((total_p)) + "")
    }


    $("#submit_btn.monthly-recurring").click(function() {
        $("#interest_table").find("tr:gt(0)").remove();
        principal = $("#principal").val()
        rate = $("#rate").val()
        time_years = $("#time_years").val()
        time_months = $("#time_months").val()
        frequency = $("input:radio[name=compoundperiod]:checked").val()
        monthlyRecurringDepositCalculator(principal, rate, time_years, time_months, frequency)
    });

    function emiCalculator(principal, rate, time_years, time_months, emi, findwhat, newThis) {

        $('#overlay').fadeIn().delay(1000).fadeOut();
        if (findwhat == "") findwhat = "findemi";
        months_in_year = 12.0;
        total_principal = 0.0;
        total_interest = 0.0;
        p = Math.abs(parseFloat(principal))
        if (isNaN(p - p)) p = 0;
        rate = (parseFloat(rate))

        if (isNaN(rate - rate)) rate = 0;
        r = rate / (100.0 * months_in_year)
        if ($("input[name=tenure_options]:checked").val() == 1) {
            n_months = (Math.abs(parseFloat(time_months)))
        } else {
            n_months = Math.abs(parseFloat(time_months));
        }


        if (isNaN(n_months - n_months)) n_months = 0;
        n_years = Math.abs(parseFloat(time_years))
        if (isNaN(n_years - n_years)) n_years = 0;
        n = Math.floor(n_years * months_in_year + n_months) //months
        emi = Math.abs(parseFloat(emi));
        if (isNaN(emi - emi)) emi = 0;

        n_years = Math.floor(n / months_in_year)
        n_months = n % months_in_year
        $("#time_years").val(n_years);

        //$("#time_months").val(n_months);


        if (findwhat == "findemi") {
            if (r == 0) {
                emi = p / n
                p_remaining = p

            } else {

                tt = 1 + r;
                tmp = Math.pow(tt, n);
                emi = p * r * tmp / (tmp - 1);
                p_remaining = p;
            }
            if (isNaN(emi - emi)) emi = 0;
            if (emi == 0) emi = p_remaining;
            // console.log(emi);
            $("#emi").val(emi.toFixed(2));
        }

        if (findwhat == "findprincipal") {
            if (r == 0) {
                p = emi * n
                p_remaining = p
            } else {
                tt = 1 + r;
                tmp = Math.pow(tt, n);
                p = emi / (r * tmp / (tmp - 1));
                p_remaining = p;
            }
            $("#principal").val(p);
        }

        if (findwhat == "findrate") {
            if (r == 0) {
                emi = p / n
                p_remaining = p
            } else {
                tt = 1 + r;
                tmp = Math.pow(tt, n);
                emi = p * r * tmp / (tmp - 1);
                p_remaining = p;
            }
            $("#emi").val(emi);
        }
        if (findwhat == "findtime") {
            console.log(emi);
            console.log(p);
            console.log(r);

            max_r = emi / p * .98;
            min_r = 0.000001;
            n = 0
            if (r > min_r && r < max_r) {
                n = (Math.log(emi) - Math.log(emi - p * r)) / (Math.log(1 + r));
                n = Math.ceil(n);
            }
            // console.log(temp);
            else {
                $("#p-error-msg").parent().show();
                $("#p-error-msg").text("Rate of interest should be between " + min_r * 1200 + " and " + max_r * 1200);
            }
            // if (r==0)
            // {
            // 	emi = p/n
            // 	p_remaining = p
            // }
            // else
            // {
            // 	tt = 1+r;
            // 	tmp = Math.pow(tt,n);
            // 	emi = p*r*tmp / (tmp - 1);
            // 	p_remaining = p;
            // }
            // n= temp;
            p_remaining = p;

            n_years = Math.floor(n / months_in_year)
            n_months = n % months_in_year

            $("#time_years").val(n_years);
            $("#time_months").val(n_months);
        }
        var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

        var m_month = 1;
        var start_emi_date = new Date($("input[name=start_emi_time]").val());
        n = 500;
        var is_loan_paid = '';
        var collapsedLevel = '';
        isShowFirst = 0;
        for (var i = 0; i <= n; i++) {
            if (i == 0) {

                //row = '<tr><td></td><td></td><td>0</td><td colspan="3" class="cellTextCenter"> -- </td><td>'+addCommaCurrency(p_remaining)+'</td><td></td><td></td><td></td><td></td></tr>';
                //$('#interest_table > tbody:last').append(row);
                continue
            }

            var output_emi_month_year = monthNames[start_emi_date.getMonth()];
            var output_emi_month = monthNames[start_emi_date.getMonth()];
            start_emi_date.setMonth(start_emi_date.getMonth() + 1);
            //console.log("p_remaining="+p_remaining+"_"+r);
            int_comp = p_remaining * r
            principal_comp = emi - int_comp
            p_remaining = p_remaining + int_comp - emi
            total_interest += int_comp
            total_principal += principal_comp
            // if(p_remaining<emi)
            // 	emi=p_remaining;
            x = Math.floor(i / months_in_year)
            year_frac = i % months_in_year


            if (i > 1) {
                row = '<tr class="'+addHide+' ' + collapsedLevel + ' ' + isShowFirst + '">';
                //row +='<td>'+(i)+'</td>';
                //row +='<td></td>';
                row += '<td>' + output_emi_month_year + '</td>';
                row += '<td><span id="interest_mk_' + i + '" class="interest_' + collapsedLevel + '" >' + addCommaCurrency((int_comp).toFixed(2)) + '</span><input type="hidden" name="interest_mk_' + i + '" value="' + int_comp + '"/></td>';
                row += '<td><span id="principle_mk_' + i + '" class="principle_' + collapsedLevel + '" >' + addCommaCurrency((principal_comp).toFixed(2)) + '</span><input type="hidden" name="principle_mk_' + i + '" value="' + principal_comp + '"/></td>';
                row += '<td><span id="balance_principle_mk_' + i + '" class="balance_principle_' + collapsedLevel + '" >' + addCommaCurrency((p_remaining).toFixed(2)) + '</span><input type="hidden" name="balance_principle_mk_' + i + '" value="' + p_remaining + '"/></td>';
                row += '<td><span id="rate_mk_' + i + '" class="rate_' + collapsedLevel + '" >' + (rate) + '</span><input type="hidden" name="rate_mk_' + i + '" value="' + rate + '"/></td>';
                row += '<td><span id="emi_mk_' + i + '" class="emi_' + collapsedLevel + '" >' + addCommaCurrency((emi).toFixed(2)) + '</span><input type="hidden" name="emi_mk_' + i + '" value="' + emi + '"/></td>';
                row += '<td><div class="form-group has-feedback has-clear"><input type="text" class="clearable form-control" class="new_rate_of_interest" name="new_rate_of_interest" style="width: 90px;" data-emi-sno-mk="' + i + '"/></div><input type="hidden" name="new_rate_of_interest_' + i + '" value=""/></td>';
                row += '<td><div class="form-group has-feedback has-clear"><input type="text" class="clearable form-control" name="pre_payment" class="pre_payment" style="width: 90px;" data-emi-sno-mk="' + i + '"/></div><input type="hidden" name="pre_payment_' + i + '" value=""/></td>';
                row += '<td><div class="form-group has-feedback has-clear"><input type="text" class="clearable form-control" name="new_emi" style="width: 90px;"  data-emi-sno-mk="' + i + '"/></div><input type="hidden" name="new_emi_' + i + '" value=""/></td>';
                row += '</tr>'
                $('#interest_table > tbody:last').append(row);
            }

            var isHide = 0;
            var addHide = '';
            if (start_emi_date.getFullYear() != collapsedLevel) {
                var openclose = 'close-collapsed';
                if (collapsedLevel != '') {
                    isShowFirst = 1;
                    openclose = 'open-collapsed';
                }
                collapsedLevel = start_emi_date.getFullYear();


                isHide = 1;

                row = '<tr class="' + addHide + ' ' + collapsedLevel + ' thisIsMyClass" data-year-root="' + collapsedLevel + '">';
                //row +='<td></td>';
                //row +='<td></td>';
                row += '<td><a href="javascript::void(0)" data-year="' + collapsedLevel + '" class="showCollapsed ' + openclose + ' first">' + collapsedLevel + '</a></td>';
                row += '<td><div id="totalTotalInterest_' + collapsedLevel + '" style="font-weight: bold;"></div></td>';
                row += '<td><div id="totalTotalPricipal_' + collapsedLevel + '" style="font-weight: bold;"></div></td>';
                row += '<td><div id="totalTotalBalancePrinciple_' + collapsedLevel + '" style="font-weight: bold;"></div></td>';
                row += '<td><div id="totalTotalRate_' + collapsedLevel + '" style="font-weight: bold;"></div></td>';
                row += '<td><div id="totalTotalEmi_' + collapsedLevel + '" style="font-weight: bold;"></div></td>';

                row += '<td><a href="javascript::void(0)" data-year="' + collapsedLevel + '" class="showCollapsed">New Rate</a></td>';
                row += '<td><a href="javascript::void(0)" data-year="' + collapsedLevel + '" class="showCollapsed">Amount Paid</a></td>';
                row += '<td><a href="javascript::void(0)" data-year="' + collapsedLevel + '" class="showCollapsed">New EMI</a></td>';
                row += '</tr>';
                $('#interest_table > tbody:last').append(row);



            }
            isHide = (isHide + 1);
            if (isShowFirst == 1) {
                addHide = 'hide';
            }

            if (i == 1) {
                row = '<tr class="' + collapsedLevel + '">';
                //row +='<td>'+(i)+'</td>';
                //row +='<td></td>';
                row += '<td>' + output_emi_month_year + '</td>';
                row += '<td><span id="interest_mk_' + i + '" class="interest_' + collapsedLevel + '">' + addCommaCurrency((int_comp).toFixed(2)) + '</span><input type="hidden" name="interest_mk_' + i + '" value="' + int_comp + '"/></td>';
                row += '<td><span id="principle_mk_' + i + '" class="principle_' + collapsedLevel + '">' + addCommaCurrency((principal_comp).toFixed(2)) + '</span><input type="hidden" name="principle_mk_' + i + '" value="' + principal_comp + '"/></td>';
                row += '<td><span id="balance_principle_mk_' + i + '" class="balance_principle_' + collapsedLevel + '" >' + addCommaCurrency((p_remaining).toFixed(2)) + '</span><input type="hidden" name="balance_principle_mk_' + i + '" value="' + p_remaining + '"/></td>';
                row += '<td><span id="rate_mk_' + i + '" class="rate_' + collapsedLevel + '" >' + (rate) + '</span><input type="hidden" name="rate_mk_' + i + '" value="' + rate + '"/></td>';
                row += '<td><span id="emi_mk_' + i + '" class="emi_' + collapsedLevel + '" >' + addCommaCurrency((emi).toFixed(2)) + '</span><input type="hidden" name="emi_mk_' + i + '" value="' + emi + '"/></td>';
                row += '<td><div class="form-group has-feedback has-clear" id="myData"><input type="text" class="clearable form-control" class="new_rate_of_interest" name="new_rate_of_interest" style="width: 90px;" data-emi-sno-mk="' + i + '"/></div><input type="hidden" name="new_rate_of_interest_' + i + '" value=""/></td>';
                row += '<td><div class="form-group has-feedback has-clear"><input type="text" class="clearable form-control" name="pre_payment" class="pre_payment" style="width: 90px;" data-emi-sno-mk="' + i + '"/></div><input type="hidden" name="pre_payment_' + i + '" value=""/></td>';
                row += '<td><div class="form-group has-feedback has-clear"><input type="text" class="clearable form-control" name="new_emi" style="width: 90px;"  data-emi-sno-mk="' + i + '"/></div><input type="hidden" name="new_emi_' + i + '" value=""/></td>';
                row += '</tr>'
                $('#interest_table > tbody:last').append(row);
            }



            if (p_remaining < 0 || principal_comp < 0) {
                is_loan_paid = 'Loan Paid';

                $("#interest_mk_" + i).text(is_loan_paid);
                $("#principle_mk_" + i).text(is_loan_paid);
                $("#balance_principle_mk_" + i).text(is_loan_paid);

                $("#rate_mk_" + i).text(is_loan_paid);
                $("#emi_mk_" + i).text(is_loan_paid);

                //break;
            }
            if (is_loan_paid == 'Loan Paid') {
                $("#interest_mk_" + i).text(is_loan_paid);
                $("#principle_mk_" + i).text(is_loan_paid);
                $("#balance_principle_mk_" + i).text(is_loan_paid);

                $("#rate_mk_" + i).text(is_loan_paid);
                $("#emi_mk_" + i).text(is_loan_paid);

                int_comp = 0;
                principal_comp = 0;
                p_remaining = 0;
            }

            m_month = (m_month + 1);
        };
        if (isNaN(emi - emi)) emi = 0;
        i_p_ratio = total_interest / total_principal;
        if (isNaN(i_p_ratio - i_p_ratio)) i_p_ratio = 0;


        $("#breakup_details").show()
        $(".breakup_details").show()


        newThis.find("#label4").text("Loan Amount: " + addCommaCurrency(p.toFixed(2)) + "")
        newThis.find("#label5").text("Rate of Interest: " + rate + "%")
        newThis.find("#label6").text("Time: " + n_years + " Years and " + n_months + " Months")
        newThis.find("#label1").text(addCommaCurrency(emi) + "")
        newThis.find("#label2").text(addCommaCurrency(total_interest.toFixed(2)) + "")
        newThis.find("#first-principal-changes").text(addCommaCurrency(total_interest.toFixed(2)) + "")
        newThis.find("#label3").text(addCommaOnly((i_p_ratio.toFixed(2))) + "")
        newThis.find("#label7").text(addCommaCurrency((total_interest + p).toFixed(2)) + "")



        // Load the Visualization API and the piechart package.
        google.charts.load('current', {
            'packages': ['corechart']
        });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

            var pieChartPercent = ((total_interest / (total_interest + p)) * 100).toFixed(2);

            newThis.find('#pei-progress').attr('style', 'width: ' + (100 - parseInt(pieChartPercent)) + '% !important');
            newThis.find('#pei-progress').attr('aria-valuenow', (100 - parseInt(pieChartPercent)));
            newThis.find('#pei-progress').html((100 - parseInt(pieChartPercent)) + "%");


            
        }


        var myIndex = 0;
        var oldMonth = 0;
        $(".thisIsMyClass").each(function(index) {
            var tttt = 0;

            $("span[class=interest_" + $(this).attr('data-year-root') + "]").each(function(index) {
                if ($(this).text() == "Loan Paid") {
                    tttt = "Loan Paid";
                } else {
                    tttt += parseFloat(removeCommas($(this).text()));
                }

            });
            if (tttt == 'Loan Paid') {
                myIndex = myIndex + 1;
                if (myIndex > 1) {
                    $("#totalTotalInterest_" + $(this).attr('data-year-root')).parent().parent().hide();
                }
                $("#totalTotalInterest_" + $(this).attr('data-year-root')).html(tttt);
            } else {
                $("#totalTotalInterest_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
            }

            var tttt = 0;
            $("span[class=principle_" + $(this).attr('data-year-root') + "]").each(function(index) {
                if ($(this).text() == "Loan Paid") {
                    tttt = "Loan Paid";
                } else {
                    tttt += parseFloat(removeCommas($(this).text()));
                }

            });
            if (tttt == 'Loan Paid') {
                $("#totalTotalPricipal_" + $(this).attr('data-year-root')).html(tttt);
            } else {
                $("#totalTotalPricipal_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
            }

            var tttt = 0;
            $("span[class=balance_principle_" + $(this).attr('data-year-root') + "]").each(function(index) {
                if ($(this).text() == "Loan Paid") {
                    tttt = "Loan Paid";
                } else {
                    tttt = parseFloat(removeCommas($(this).text()));
                }

            });
            if (tttt == 'Loan Paid') {
                $("#totalTotalBalancePrinciple_" + $(this).attr('data-year-root')).html(tttt);
            } else {
                $("#totalTotalBalancePrinciple_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
            }


            var tttt = 0;
            $("span[class=rate_" + $(this).attr('data-year-root') + "]").each(function(index) {
                if ($(this).text() == "Loan Paid") {
                    tttt = "Loan Paid";
                } else {
                    tttt = parseFloat(($(this).text()));
                }

            });
            if (tttt == 'Loan Paid') {
                $("#totalTotalRate_" + $(this).attr('data-year-root')).html(tttt);
            } else {
                $("#totalTotalRate_" + $(this).attr('data-year-root')).html((tttt));
            }

            var tttt = 0;
            $("span[class=emi_" + $(this).attr('data-year-root') + "]").each(function(index) {
                if ($(this).text() == "Loan Paid") {
                    tttt = "Loan Paid";
                } else {
                    oldMonth = oldMonth + 1;
                    tttt = parseFloat(removeCommas($(this).text()));
                }

            });
            if (tttt == 'Loan Paid') {
                $("#totalTotalEmi_" + $(this).attr('data-year-root')).html(tttt);
            } else {
                $("#totalTotalEmi_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
            }


        });
        $("input[name=oldMonth]").val(oldMonth);


        $(".showCollapsed").click(function() {
            //alert($("."+$(this).attr("data-year")).hasClass('hide'));
            if ($("." + $(this).attr("data-year")).hasClass('hide')) {
                $("." + $(this).attr("data-year")).removeClass('hide');
                $("." + $(this).attr("data-year")).first().removeClass("hide");


                $(this).parent().parent().find('.first').removeClass("open-collapsed");
                $(this).parent().parent().find('.first').addClass("close-collapsed");

            } else {
                $("." + $(this).attr("data-year")).addClass('hide');
                $("." + $(this).attr("data-year")).first().removeClass("hide");

                $(this).parent().parent().find('.first').addClass("open-collapsed");
                $(this).parent().parent().find('.first').removeClass("close-collapsed");
            }



            //alert($(this).attr("data-year"));
        });


        var fire_level3 = false;
        $("input[name=new_emi]").focus(function() {
            if ($(this).val() > 0) {
                fire_level3 = true;
            } else {
                fire_level3 = false;
            }
        });


        $("input[name=new_emi]").on('blur', function(e) {
            var oldValue = $(this).attr('oldValue');
			var thisVal = $(this).val();
			var data_emi_sno_mk = $(this).attr("data-emi-sno-mk");

            if (thisVal === oldValue) {
                return false;
            }
			$('#overlay').fadeIn(100,function() {

            if (thisVal > 0) {
                fire_level3 = true;
            }

            if (fire_level3) {
                // start New Emi
                var is_loan_paid = '';
                var total_length = n;
                

                var currentRate = $("input[name=emi]").val();
                $("input[name=new_emi]").each(function(index) {

                    if ($(this).val() != currentRate && $(this).val() > 0) {
                        currentRate = $(this).val();
                    }
                    $("#emi_mk_" + (index + 2)).text(Math.trunc(currentRate));
                    $("input[name=emi_mk_" + (index + 2) + "]").val(currentRate);

                });


                for (var i = (parseInt(data_emi_sno_mk)); i <= total_length; i++) {

                    if (i == 1) {
                        var new_principle_amount = parseFloat($("input[name=principal]").val());
                    } else {
                        var new_principle_amount = parseFloat($("input[name=balance_principle_mk_" + (i - 1) + "]").val());
                    }


                    var new_rate = $("input[name=rate_mk_" + (i) + "]").val();
                    var new_interest = (((new_principle_amount * new_rate) / 12 / 100));

                    //console.log(new_principle_amount+"_*"+new_rate);
                    if (addCommaCurrency(new_interest.toFixed(2)) == 0 || addCommaCurrency(new_interest.toFixed(2)) < 0) {
                        is_loan_paid = 'Loan Paid';
                    }
                    $("#interest_mk_" + (i)).text(is_loan_paid == '' ? addCommaCurrency(new_interest.toFixed(2)) : is_loan_paid);
                    $("input[name=interest_mk_" + (i) + "]").val(new_interest.toFixed(2));

                    var new_emi = $("input[name=emi_mk_" + (i) + "]").val();

                    var new_principle = (parseFloat(new_emi) - parseFloat(new_interest));
                    //console.log(new_emi+"_"+new_interest);
                    $("#principle_mk_" + (i)).text(is_loan_paid == '' ? addCommaCurrency(new_principle.toFixed(2)) : is_loan_paid);
                    $("input[name=principle_mk_" + (i) + "]").val(new_principle.toFixed(2));


                    var new_balance_principle = (new_principle_amount - new_principle - $("input[name=pre_payment_" + i + "]").val());

                    $("#balance_principle_mk_" + i).text(is_loan_paid == '' ? addCommaCurrency(new_balance_principle.toFixed(2)) : is_loan_paid);
                    $("input[name=balance_principle_mk_" + i + "]").val(new_balance_principle.toFixed(2));

                    if (is_loan_paid != '') {
                        //$("#rate_mk_"+i).text(is_loan_paid);
                        //$("#emi_mk_"+i).text(is_loan_paid);
                    }

                    if (new_interest == 0 || new_interest < 0) {
                        is_loan_paid = 'Loan Paid';
                        $("#interest_mk_" + i).text(is_loan_paid);
                        $("#principle_mk_" + i).text(is_loan_paid);
                        $("#balance_principle_mk_" + i).text(is_loan_paid);

                        $("#rate_mk_" + i).text(is_loan_paid);
                        $("#emi_mk_" + i).text(is_loan_paid);
                    }

                }
                var totalMonth = 0;
                var total_amount_paid_end_year = 0.0;
                var total_new_interest = 0.0;
                var total_new_principle = 0.0;
                var total_pre_payment = 0;
                for (var k = 1; k <= n; k++) {
                    if ($("#interest_mk_" + k).text() != 'Loan Paid') {
                        totalMonth = totalMonth + 1;
                        var data_data_1 = parseFloat($("input[name=interest_mk_" + k + "]").val());
                        total_new_interest = (total_new_interest + data_data_1);
                    }
                    if ($("#principle_mk_" + k).text() != 'Loan Paid') {
                        total_new_principle = (total_new_principle + parseFloat($("input[name=principle_mk_" + k + "]").val()));
                    }
                }
                $("input[name=pre_payment]").each(function() {
                    if (parseFloat($(this).val()) > 0.0) {
                        total_pre_payment = (total_pre_payment + parseFloat($(this).val()));
                    }
                });

                total_amount_paid_end_year = (total_new_interest + total_new_principle + total_pre_payment);
                //console.log(total_new_interest+"_"+total_new_principle+"_"+total_pre_payment);
                //$("HTML, BODY").animate({scrollTop: 0}, 1000);

                //alert($("input[name=interest_mk_"+data_emi_sno_mk+"]").val()+"__"+thisVal);
                if (parseFloat(thisVal) < parseFloat($("input[name=interest_mk_" + data_emi_sno_mk + "]").val())) {
                    $("#success-message").hide();
                    $("#show-alert-message").click();
                    $("#warning-message").show();
                    $("#warning-message").html("The loan can not be paid since new EMI is less than the monthly interest");
                } else {
					
					var benefitOrLoss = Number($("#first-principal-changes").text().replace(/\,/g, '')) - (total_amount_paid_end_year - p).toFixed(2);
					
					if(benefitOrLoss >= 0)
					{
						$("#warning-message").hide();
						$("#show-alert-message").click();
						$("#success-message").show();
						$("#success-message").html("Saving in interest amount : ₹ " + addCommaCurrency(+benefitOrLoss) + "<br/> Saving in month(s) : " + ($('input[name=oldMonth]').val() - totalMonth));
					} 
					else
					{
						$("#success-message").hide();
						$("#show-alert-message").click();
						$("#warning-message").show();
						$("#warning-message").html("Loss of interest amount : ₹ " + addCommaCurrency(+benefitOrLoss) + "<br/> Additional month(s) : " + ($('input[name=oldMonth]').val() - totalMonth));
					}
                }


                $("#label2").text(addCommaCurrency((total_amount_paid_end_year - p).toFixed(2)).replace("-", ""));
                $("#label7").text(addCommaCurrency(total_amount_paid_end_year.toFixed(2)));


                // Load the Visualization API and the piechart package.
                google.charts.load('current', {
                    'packages': ['corechart']
                });
                google.charts.setOnLoadCallback(drawChart);

                function drawChart() {

                    var pieChartPercent = (((total_amount_paid_end_year - p) / total_amount_paid_end_year) * 100).toFixed(2);

                    $("#pei-progress").attr('style', 'width: ' + (100 - parseInt(pieChartPercent)) + '% !important');
                    $("#pei-progress").attr('aria-valuenow', (100 - parseInt(pieChartPercent)));
                    $("#pei-progress").html((100 - parseInt(pieChartPercent)) + "%");

                    
                }
            }



            var myIndex = 0;
            $(".thisIsMyClass").each(function(index) {
                var tttt = 0;var currentRow = $(this);
                $("span[class=interest_" + $(this).attr('data-year-root') + "]").each(function(index) {
                    if ($(this).text() == "Loan Paid") {
                        tttt = "Loan Paid";
                        myIndex = index + 1;
                    } else {
                        currentRow.show();
                        tttt += parseFloat(removeCommas($(this).text()));
                    }

                });

                if (tttt == 'Loan Paid') {
                    myIndex = myIndex + 1;
                    if (myIndex > 1) {
                        var mainYear = (parseInt($(this).attr('data-year-root')) + 1);
                        //console.log($(this).attr('data-year-root') + "_"+mainYear);
                        $("#totalTotalInterest_" + mainYear).parent().parent().hide();
                    }
                    $("#totalTotalInterest_" + $(this).attr('data-year-root')).html(tttt);
                } else {
                    $("#totalTotalInterest_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
                }

                var tttt = 0;
                $("span[class=principle_" + $(this).attr('data-year-root') + "]").each(function(index) {
                    if ($(this).text() == "Loan Paid") {
                        tttt = "Loan Paid";
                    } else {
                        tttt += parseFloat(removeCommas($(this).text()));
                    }

                });
                if (tttt == 'Loan Paid') {
                    $("#totalTotalPricipal_" + $(this).attr('data-year-root')).html(tttt);
                } else {
                    $("#totalTotalPricipal_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
                }

                var tttt = 0;
                $("span[class=balance_principle_" + $(this).attr('data-year-root') + "]").each(function(index) {
                    if ($(this).text() == "Loan Paid") {
                        tttt = "Loan Paid";
                    } else {
                        tttt = parseFloat(removeCommas($(this).text()));
                    }

                });
                if (tttt == 'Loan Paid') {
                    $("#totalTotalBalancePrinciple_" + $(this).attr('data-year-root')).html(tttt);
                } else {
                    $("#totalTotalBalancePrinciple_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
                }


                var tttt = 0;
                $("span[class=rate_" + $(this).attr('data-year-root') + "]").each(function(index) {
                    if ($(this).text() == "Loan Paid") {
                        tttt = "Loan Paid";
                    } else {
                        tttt = parseFloat(($(this).text()));
                    }

                });
                if (tttt == 'Loan Paid') {
                    $("#totalTotalRate_" + $(this).attr('data-year-root')).html(tttt);
                } else {
                    $("#totalTotalRate_" + $(this).attr('data-year-root')).html((tttt));
                }

                var tttt = 0;
                $("span[class=emi_" + $(this).attr('data-year-root') + "]").each(function(index) {
                    if ($(this).text() == "Loan Paid") {
                        tttt = "Loan Paid";
                    } else {
                        tttt = parseFloat(removeCommas($(this).text()));
                    }

                });
                if (tttt == 'Loan Paid') {
                    $("#totalTotalEmi_" + $(this).attr('data-year-root')).html(tttt);
                } else {
                    $("#totalTotalEmi_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
                }
            });
				$('#overlay').fadeOut();
			});
        });

        var fire_level2 = false;
        $("input[name=pre_payment]").focus(function() {
            if ($(this).val() > 0) {
                fire_level2 = true;
            } else {
                fire_level2 = false;
            }
        });

        $("input[name=pre_payment]").blur(function() {

            var oldValue = $(this).attr('oldValue');
			var thisVal = $(this).val();
			var data_emi_sno_mk = $(this).attr("data-emi-sno-mk");

            if (thisVal === oldValue) {
                return false;
            }

            $('#overlay').fadeIn(100,function() {

				if (thisVal > 0) {
					fire_level2 = true;
				}
				if (fire_level2) {
					var total_length = n;
					if (thisVal == 'undefined' || thisVal == null) {
						thisVal = 0;
					}

					
					$("input[name=pre_payment_" + data_emi_sno_mk + "]").val(thisVal);

					var is_loan_paid = '';
					for (var i = (parseInt(data_emi_sno_mk)); i <= total_length; i++) {

						if (i == 1) {
							var new_principle_amount = parseFloat($("input[name=principal]").val());
						} else {
							var new_principle_amount = parseFloat($("input[name=balance_principle_mk_" + (i - 1) + "]").val());
						}


						var new_rate = $("input[name=rate_mk_" + (i) + "]").val();
						var new_interest = ((new_principle_amount * new_rate) / 12 / 100);

						$("#interest_mk_" + (i)).text(is_loan_paid == '' ? addCommaCurrency(new_interest.toFixed(2)) : is_loan_paid);
						$("input[name=interest_mk_" + (i) + "]").val(new_interest);

						var new_emi = $("input[name=emi_mk_" + (i) + "]").val();
						var new_principle = (parseFloat(new_emi) - parseFloat(new_interest));
						$("#principle_mk_" + (i)).text(is_loan_paid == '' ? addCommaCurrency(new_principle.toFixed(2)) : is_loan_paid);
						$("input[name=principle_mk_" + (i) + "]").val(new_principle.toFixed(2));


						var new_balance_principle = (new_principle_amount - new_principle - $("input[name=pre_payment_" + i + "]").val());

						$("#balance_principle_mk_" + i).text(is_loan_paid == '' ? addCommaCurrency(new_balance_principle.toFixed(2)) : is_loan_paid);
						$("input[name=balance_principle_mk_" + i + "]").val(new_balance_principle);

						if (is_loan_paid != '') {
							//$("#rate_mk_"+i).text(is_loan_paid);
							//$("#emi_mk_"+i).text(is_loan_paid);
						}

						if (new_interest == 0 || new_interest < 0) {
							is_loan_paid = 'Loan Paid';
							$("#interest_mk_" + i).text(is_loan_paid);
							$("#principle_mk_" + i).text(is_loan_paid);
							$("#balance_principle_mk_" + i).text(is_loan_paid);

							$("#rate_mk_" + i).text(is_loan_paid);
							$("#emi_mk_" + i).text(is_loan_paid);
						}

					}
					var totalMonth = 0;
					var total_amount_paid_end_year = 0.0;
					var total_new_interest = 0.0;
					var total_new_principle = 0.0;
					var total_pre_payment = 0;
					for (var k = 1; k <= n; k++) {
						if ($("#interest_mk_" + k).text() != 'Loan Paid') {
							totalMonth = totalMonth + 1;
							var data_data_1 = parseFloat($("input[name=interest_mk_" + k + "]").val());
							total_new_interest = (total_new_interest + data_data_1);
						}
						if ($("#principle_mk_" + k).text() != 'Loan Paid') {
							total_new_principle = (total_new_principle + parseFloat($("input[name=principle_mk_" + k + "]").val()));
						}
					}

					$("input[name=pre_payment]").each(function() {

						if (parseFloat($(this).val()) > 0) {
							total_pre_payment = (total_pre_payment + parseFloat($(this).val()));
						}

					});

					total_amount_paid_end_year = (total_new_interest + total_new_principle + total_pre_payment);
					
					var benefitOrLoss = Number($("#first-principal-changes").text().replace(/\,/g, '')) - (total_amount_paid_end_year - p).toFixed(2);
					
					if(benefitOrLoss >= 0)
					{
						$("#warning-message").hide();
						$("#show-alert-message").click();
						$("#success-message").show();
						$("#success-message").html("Saving in interest amount : ₹ " + addCommaCurrency(+benefitOrLoss) + "<br/> Saving in month(s) : " + ($('input[name=oldMonth]').val() - totalMonth));
					} 
					else
					{
						$("#success-message").hide();
						$("#show-alert-message").click();
						$("#warning-message").show();
						$("#warning-message").html("Loss of interest amount : ₹ " + addCommaCurrency(+benefitOrLoss) + "<br/> Additional month(s) : " + ($('input[name=oldMonth]').val() - totalMonth));
					}


					$("#label2").text(addCommaCurrency((total_amount_paid_end_year - p).toFixed(2)));
					$("#label7").text(addCommaCurrency(total_amount_paid_end_year.toFixed(2)));


					// Load the Visualization API and the piechart package.
					google.charts.load('current', {
						'packages': ['corechart']
					});
					google.charts.setOnLoadCallback(drawChart);

					function drawChart() {

						var pieChartPercent = (((total_amount_paid_end_year - p) / total_amount_paid_end_year) * 100).toFixed(2);

						$("#pei-progress").attr('style', 'width: ' + (100 - parseInt(pieChartPercent)) + '% !important');
						$("#pei-progress").attr('aria-valuenow', (100 - parseInt(pieChartPercent)));
						$("#pei-progress").html((100 - parseInt(pieChartPercent)) + "%");
					}

				}
				// end Pre-Payment


				var myIndex = 0;
				$(".thisIsMyClass").each(function(index) {
					var tttt = 0; var currentRow = $(this);
					$("span[class=interest_" + $(this).attr('data-year-root') + "]").each(function(index) {
						if ($(this).text() == "Loan Paid") {
							tttt = "Loan Paid";

						} else {
                            currentRow.show();
							tttt += parseFloat(removeCommas($(this).text()));
						}

					});
					if (tttt == 'Loan Paid') {
						myIndex = myIndex + 1;
						if (myIndex > 1) {
							$("#totalTotalInterest_" + $(this).attr('data-year-root')).parent().parent().hide();
						}
						$("#totalTotalInterest_" + $(this).attr('data-year-root')).html(tttt);
					} else {
						$("#totalTotalInterest_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
					}

					var tttt = 0;
					$("span[class=principle_" + $(this).attr('data-year-root') + "]").each(function(index) {
						if ($(this).text() == "Loan Paid") {
							tttt = "Loan Paid";
						} else {
							tttt += parseFloat(removeCommas($(this).text()));
						}

					});
					if (tttt == 'Loan Paid') {
						$("#totalTotalPricipal_" + $(this).attr('data-year-root')).html(tttt);
					} else {
						$("#totalTotalPricipal_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
					}

					var tttt = 0;
					$("span[class=balance_principle_" + $(this).attr('data-year-root') + "]").each(function(index) {
						if ($(this).text() == "Loan Paid") {
							tttt = "Loan Paid";
						} else {
							tttt = parseFloat(removeCommas($(this).text()));
						}

					});
					if (tttt == 'Loan Paid') {
						$("#totalTotalBalancePrinciple_" + $(this).attr('data-year-root')).html(tttt);
					} else {
						$("#totalTotalBalancePrinciple_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
					}


					var tttt = 0;
					$("span[class=rate_" + $(this).attr('data-year-root') + "]").each(function(index) {
						if ($(this).text() == "Loan Paid") {
							tttt = "Loan Paid";
						} else {
							tttt = parseFloat(($(this).text()));
						}

					});
					if (tttt == 'Loan Paid') {
						$("#totalTotalRate_" + $(this).attr('data-year-root')).html(tttt);
					} else {
						$("#totalTotalRate_" + $(this).attr('data-year-root')).html((tttt));
					}

					var tttt = 0;
					$("span[class=emi_" + $(this).attr('data-year-root') + "]").each(function(index) {
						if ($(this).text() == "Loan Paid") {
							tttt = "Loan Paid";
						} else {
							tttt = parseFloat(removeCommas($(this).text()));
						}

					});
					if (tttt == 'Loan Paid') {
						$("#totalTotalEmi_" + $(this).attr('data-year-root')).html(tttt);
					} else {
						$("#totalTotalEmi_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
					}
				});
				$('#overlay').fadeOut();
			});
        });

        var fire_level1 = false;
        $("input[name=new_rate_of_interest]").focus(function() {
            if ($(this).val() > 0) {
                fire_level1 = true;
            } else {
                fire_level1 = false;
            }
        });


        $("input[name=new_rate_of_interest]").blur(function() {

            var oldValue = $(this).attr('oldValue');
			var thisVal = $(this).val();
			var data_emi_sno_mk = $(this).attr("data-emi-sno-mk");

            if (thisVal === oldValue) {
                return false;
            }

            $('#overlay').fadeIn(100,function() {
				if (thisVal > 0) {
					fire_level1 = true;
				}
	
				if (fire_level1) {
	
					var currentRate = $("input[name=rate-show]").val();
					$("input[name=new_rate_of_interest]").each(function(index) {
	
						if ($(this).val() != currentRate && $(this).val() > 0) {
							currentRate = $(this).val();
						}
						$("#rate_mk_" + (index + 2)).text((currentRate));
						$("input[name=rate_mk_" + (index + 2) + "]").val(currentRate);
	
					});
	
					var total_length = n;
					
	
					if ($(this).val() == '') {
						thisVal = $("input[name=rate_mk_" + (data_emi_sno_mk - 1) + "]").val();
					}
					if (thisVal == 'undefined' || thisVal == null) {
						thisVal = $("input[name=rate_mk_" + (data_emi_sno_mk) + "]").val();
					}
					$("input[name=new_rate_of_interest_" + data_emi_sno_mk + "]").val(thisVal);
	
					var is_loan_paid = '';
	
					for (var i = (parseInt(data_emi_sno_mk)); i <= total_length; i++) {
	
						if (i == 1) {
							var new_principle_amount = parseFloat($("input[name=principal]").val());
						} else {
							var new_principle_amount = parseFloat($("input[name=balance_principle_mk_" + (i - 1) + "]").val());
						}
	
						var new_rate = $("input[name=rate_mk_" + (i) + "]").val();
						var new_interest = ((new_principle_amount * new_rate) / 12 / 100);
						if (addCommaCurrency(new_interest.toFixed(2)) == 0 || addCommaCurrency(new_interest.toFixed(2)) < 0) {
							is_loan_paid = 'Loan Paid';
						}
	
						$("#interest_mk_" + (i)).text(is_loan_paid == '' ? addCommaCurrency(new_interest.toFixed(2)) : is_loan_paid);
						$("input[name=interest_mk_" + (i) + "]").val(new_interest);
	
	
	
						var new_emi = $("input[name=emi_mk_" + (i) + "]").val();
						var new_principle = (parseFloat(new_emi) - parseFloat(new_interest));
						$("#principle_mk_" + (i)).text(is_loan_paid == '' ? addCommaCurrency(new_principle.toFixed(2)) : is_loan_paid);
						$("input[name=principle_mk_" + (i) + "]").val(new_principle.toFixed(2));
	
	
						var new_balance_principle = (new_principle_amount - new_principle - $("input[name=pre_payment_" + i + "]").val());
	
						$("#balance_principle_mk_" + i).text(is_loan_paid == '' ? addCommaCurrency(new_balance_principle.toFixed(2)) : is_loan_paid);
						$("input[name=balance_principle_mk_" + i + "]").val(new_balance_principle);
	
	
	
						if (new_interest == 0 || new_interest < 0) {
							is_loan_paid = 'Loan Paid';
	
							$("#interest_mk_" + i).text(is_loan_paid);
							$("#principle_mk_" + i).text(is_loan_paid);
							$("#balance_principle_mk_" + i).text(is_loan_paid);
	
							$("#rate_mk_" + i).text(is_loan_paid);
							$("#emi_mk_" + i).text(is_loan_paid);
						}
	
					}
					var totalMonth = 0;
					var total_amount_paid_end_year = 0.0;
					var total_new_interest = 0.0;
					var total_new_principle = 0.0;
					var total_pre_payment = 0;
					for (var k = 1; k <= n; k++) {
						if ($("#interest_mk_" + k).text() != 'Loan Paid') {
							totalMonth = totalMonth + 1;
							var data_data_1 = parseFloat($("input[name=interest_mk_" + k + "]").val());
							total_new_interest = (total_new_interest + data_data_1);
						}
						if ($("#principle_mk_" + k).text() != 'Loan Paid') {
							total_new_principle = (total_new_principle + parseFloat($("input[name=principle_mk_" + k + "]").val()));
						}
					}
	
					$(".pre_payment").each(function() {
						if (parseFloat($(this).val()) > 0.0) {
							total_pre_payment = (total_pre_payment + parseFloat($(this).val()));
						}
					});
					//console.log("total_new_principle="+total_new_principle);
					total_amount_paid_end_year = (total_new_interest + total_new_principle + total_pre_payment);
	
					var benefitOrLoss = Number($("#first-principal-changes").text().replace(/\,/g, '')) - (total_amount_paid_end_year - p).toFixed(2);
					
					if(benefitOrLoss >= 0)
					{
						$("#warning-message").hide();
						$("#show-alert-message").click();
						$("#success-message").show();
						$("#success-message").html("Saving in interest amount : ₹ " + addCommaCurrency(+benefitOrLoss) + "<br/> Saving in month(s) : " + ($('input[name=oldMonth]').val() - totalMonth));
					} 
					else
					{
						$("#success-message").hide();
						$("#show-alert-message").click();
						$("#warning-message").show();
						$("#warning-message").html("Loss of interest amount : ₹ " + addCommaCurrency(+benefitOrLoss) + "<br/> Additional month(s) : " + ($('input[name=oldMonth]').val() - totalMonth));
					}
	
	
					$("#label2").text(addCommaCurrency((total_amount_paid_end_year - p).toFixed(2)));
					$("#label7").text(addCommaCurrency(total_amount_paid_end_year.toFixed(2)));
	
	
					// Load the Visualization API and the piechart package.
					google.charts.load('current', {
						'packages': ['corechart']
					});
					google.charts.setOnLoadCallback(drawChart);
	
					function drawChart() {
	
						var pieChartPercent = (((total_amount_paid_end_year - p) / total_amount_paid_end_year) * 100).toFixed(2);
	
						$("#pei-progress").attr('style', 'width: ' + (100 - parseInt(pieChartPercent)) + '% !important');
						$("#pei-progress").attr('aria-valuenow', (100 - parseInt(pieChartPercent)));
						$("#pei-progress").html((100 - parseInt(pieChartPercent)) + "%");
						
					}
	
				}
				//setTimeout(function(){ $("body").removeClass("loading"); }, 2000);
	
				var myIndex = 0;
				$(".thisIsMyClass").each(function(index) {
					var tttt = 0; var currentRow = $(this);
					$("span[class=interest_" + $(this).attr('data-year-root') + "]").each(function(index) {
						if ($(this).text() == "Loan Paid") {
							tttt = "Loan Paid";
	
						} else {
                            currentRow.show();
							tttt += parseFloat(removeCommas($(this).text()));
						}
	
					});
					if (tttt == 'Loan Paid') {
						myIndex = myIndex + 1;
						if (myIndex > 2) {
							$("#totalTotalInterest_" + $(this).attr('data-year-root')).parent().parent().hide();
						}
						$("#totalTotalInterest_" + $(this).attr('data-year-root')).html(tttt);
					} else {
						$("#totalTotalInterest_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
					}
	
					var tttt = 0;
					$("span[class=principle_" + $(this).attr('data-year-root') + "]").each(function(index) {
						if ($(this).text() == "Loan Paid") {
							tttt = "Loan Paid";
						} else {
							tttt += parseFloat(removeCommas($(this).text()));
						}
	
					});
					if (tttt == 'Loan Paid') {
						$("#totalTotalPricipal_" + $(this).attr('data-year-root')).html(tttt);
					} else {
						$("#totalTotalPricipal_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
					}
	
					var tttt = 0;
					$("span[class=balance_principle_" + $(this).attr('data-year-root') + "]").each(function(index) {
						if ($(this).text() == "Loan Paid") {
							tttt = "Loan Paid";
						} else {
							tttt = parseFloat(removeCommas($(this).text()));
						}
	
					});
					if (tttt == 'Loan Paid') {
						$("#totalTotalBalancePrinciple_" + $(this).attr('data-year-root')).html(tttt);
					} else {
						$("#totalTotalBalancePrinciple_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
					}
	
	
					var tttt = 0;
					$("span[class=rate_" + $(this).attr('data-year-root') + "]").each(function(index) {
						if ($(this).text() == "Loan Paid") {
							tttt = "Loan Paid";
						} else {
							tttt = parseFloat(($(this).text()));
						}
	
					});
					if (tttt == 'Loan Paid') {
						$("#totalTotalRate_" + $(this).attr('data-year-root')).html(tttt);
					} else {
						$("#totalTotalRate_" + $(this).attr('data-year-root')).html((tttt));
					}
	
					var tttt = 0;
					$("span[class=emi_" + $(this).attr('data-year-root') + "]").each(function(index) {
						if ($(this).text() == "Loan Paid") {
							tttt = "Loan Paid";
						} else {
							tttt = parseFloat(removeCommas($(this).text()));
						}
	
					});
					if (tttt == 'Loan Paid') {
						$("#totalTotalEmi_" + $(this).attr('data-year-root')).html(tttt);
					} else {
						$("#totalTotalEmi_" + $(this).attr('data-year-root')).html(addCommaCurrency(tttt.toFixed(2)));
					}
				});
				$('#overlay').fadeOut();
			});
        });
    }

    //EMI Page


    $("input[name='calcoptions']").change(function(event) {
        console.log("event fired");
        $("#submit_btn.emi-calculator").trigger("click");
    });

    $(document).on('click', '#submit_btn.emi-calculator', function() {

        $("#interest_table").find("tr:gt(0)").remove();
        $("#p-error-msg").parent().hide();
        var elemPrincipal = $("#principal");
        var elemRate = $("#rate-show");
        var elemTimeYears = $("#time_years");
        var elemTimeMonths = $("#time_months");

        var elemEmi = $("#emi");

        //var principal = elemPrincipal.val();
        var principal = $(this).parents('form').find('input[name="principal"]').val();
        //alert($(this).parents('form').find('input[name="principal"]').val());

        //var rate = elemRate.val();
        var rate = $(this).parents('form').find('input[name="rate-show"]').val();

        //var time_years = elemTimeYears.val();
        //var time_months = elemTimeMonths.val();

        var time_years = $(this).parents('form').find('input[name="time_years"]').val();
        var time_months = $(this).parents('form').find('input[name="time_months"]').val();


        var emi = elemEmi.val();

        var findwhat = "";
        var findwhatSelected = $("input[type='radio'][name='calcoptions']:checked");
        if (findwhatSelected.length > 0) {
            findwhat = findwhatSelected.val();
            console.log(findwhat);
        }
        switch (findwhat) {
            case "findemi":
                elemEmi.attr("disabled", "disabled");
                elemPrincipal.removeAttr("disabled");
                elemRate.removeAttr("disabled");
                elemTimeYears.removeAttr("disabled");
                elemTimeMonths.removeAttr("disabled");
                break;
            case "findprincipal":
                elemPrincipal.attr("disabled", "disabled");
                elemEmi.removeAttr("disabled");
                elemRate.removeAttr("disabled");
                elemTimeYears.removeAttr("disabled");
                elemTimeMonths.removeAttr("disabled");
                break;
            case "findrate":
                elemRate.attr("disabled", "disabled");
                elemPrincipal.removeAttr("disabled");
                elemEmi.removeAttr("disabled");
                elemTimeYears.removeAttr("disabled");
                elemTimeMonths.removeAttr("disabled");
                break;
            case "findtime":
                elemTimeYears.attr("disabled", "disabled");
                elemTimeMonths.attr("disabled", "disabled");
                elemPrincipal.removeAttr("disabled");
                elemRate.removeAttr("disabled");
                elemEmi.removeAttr("disabled");
                break;

        }

        emiCalculator(principal, rate, time_years, time_months, emi, findwhat, $(this).parents('form'))
    });

    $("#reset_btn").click(function() {
        this.form.reset()
        $("#breakup_details").hide()
        $(".breakup_details").hide()
    });

    $("#print_btn.recurring-deposit").click(function() {
        $("#calculator_div").append("<div id='printable_area'></div>")
        $("#printable_area").append($("#calculator_heading").clone())
        $("#printable_area").append("<hr/><div>Recurring Principal: " + addCommaCurrency($("#principal").val()) +
            "<br/> Rate of Interest: " + $("#rate").val() + "%<br/> Time (years): " + $("#time").val() + "</div><hr/>")
        $("#printable_area").append("<div class='textMajor'>" + $("#label1").text() +
            "<br/>" + $("#label2").text() + "<br/>" + $("#label3").text() + "</div><hr/>")
        $("#printable_area").append("<h3>Breakup Chart</h3>")
        $("#printable_area").append($("#interest_table").clone().addClass("printTextSize"))
        window.print()
        $("#printable_area").remove()
    });

    $("#print_btn.emi-calculator").click(function() {
        $("#calculator_div").append("<div id='printable_area'></div>")
        $("#printable_area").append($("#calculator_heading").clone())
        $("#printable_area").append("<hr/><div>Loan Amount: " + addCommaCurrency($("#principal").val()) +
            "<br/> Rate of Interest: " + $("#rate").val() + "%<br/> Loan Term: " + convertToNum($("#time_years").val()) +
            " Years, " + convertToNum($("#time_months").val()) + " Months</div><hr/>")
        $("#printable_area").append("<div class='textMajor'>" + $("#label1").text() +
            "<br/>" + $("#label2").text() + "<br/>" + $("#label3").text() + "</div><hr/>")
        $("#printable_area").append("<h3>Breakup Chart</h3>")
        $("#printable_area").append($("#interest_table").clone().addClass("printTextSize"))
        window.print()
        $("#printable_area").remove()
    });
});

function tog(v) {
    return v ? 'addClass' : 'removeClass';
}
$(document).on('input', '.clearable', function() {
    $(this)[tog(this.value)]('x');
}).on('mousemove', '.x', function(e) {
    $(this)[tog(this.offsetWidth - 18 < e.clientX - this.getBoundingClientRect().left)]('onX');
}).on('touchstart click', '.onX', function(ev) {
    ev.preventDefault();
    $(this).removeClass('x onX').val('').change();
});