<?php
$banks = json_decode(file_get_contents("https://www.visveya.com/vnabler.com/api/get-bank"));
?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests"> 

   <head>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	  <link href="https://moneycalculators.net/emi-calculator/static/css/calculator_css.css" rel="stylesheet" />
	  
	  <link rel="stylesheet" href="https://select2.github.io/select2-bootstrap-theme/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
		<link rel="stylesheet" href="https://select2.github.io/select2-bootstrap-theme/css/select2-bootstrap.css">
		<link rel="stylesheet" href="https://select2.github.io/select2-bootstrap-theme/css/gh-pages.css">
<style>

.navbar-inverse {
    background-color: #fff;
    border-color: #fff;
}

</style>
   </head>
   <body>
      <div id="overlay" style="display:none;">
         <div class="spinner"></div>
         <br/>
         Pocessing...
      </div>
      <!-- Button trigger modal -->
      <button type="button" class="btn btn-primary hide" id="show-alert-message" data-toggle="modal" data-target="#exampleModalCenter">
      </button>
      <!-- Modal -->
      <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
         <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
               <div class="modal-header" style="font-size: 18px;font-weight: 700;">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true" style="font-size: 32px;">&times;</span>
				  </button>
				  Impact of the change(s)
               </div>
               <div class="modal-body">
                  <div class="alert alert-danger" id="warning-message" role="alert" style="display: none;"></div>
                  <div class="alert alert-success" id="success-message" role="alert" style="display: none;"></div>
               </div>
            </div>
         </div>
      </div>
      <?php include $_SERVER['DOCUMENT_ROOT'].'/views/templates/leftNav2.php';?>
	  <div class="container" style="margin-top: 3%;">
		<h3 class="text-center">Find IFSC, MICR Codes & Address of All Banks</h3><br><br>
	  	<div class="row">
		  	<div class="col-md-6">

			  	<div class="row">
					<div class="col-md-12">
					
						<div class="form-group col-md-12">
							<label for="single" class="control-label">Please Select Bank</label>
							<select id="single" class="form-control select2-bank ifsc-bank" name="ifsc-bank">
								<option value="">Select a Bank</option>
								<?php 
								foreach($banks as $bank){
									echo '<option value="'.$bank->bank_name.'">'.$bank->bank_name.'</option>';
								}
								?>
							</select>
						</div>

						<div class="form-group col-md-12">
							<label for="single" class="control-label">Please Select State</label>
							<select id="single" class="form-control select2-state" name="ifsc-state"></select>
						</div>

						<div class="form-group col-md-6">
							<label for="single" class="control-label">Please Select City</label>
							<select id="single" class="form-control select2-city" name="ifsc-city"></select>
						</div>

						<div class="form-group col-md-6">
							<label for="single" class="control-label">Please Select Branch</label>
							<select id="single" class="form-control select2-branch" name="ifsc-branch"></select>
						</div>

					</div>
					<div class="col-md-12">
						<hr/>
						<h3>Or Enter IFSC Code to know Bank details</h3><br>
						<div class="form-group col-md-8">
							<label for="single" class="control-label" style="width: 100%;">IFSC Code
								<a href="javascript::void(0)" class="reset-details" style="float: right;">Reset Details</a>
							</label>
							<input type="text" class="form-control" name="ifsc-code" placeholder="Enter IFSC Code">
							<p class="error-holder" id="ifsc_error" style="display: none; color: red;">IFSC request not verified.<p>
						</div>
						<div class="form-group col-md-4">
							<label for="single" class="control-label">&nbsp;</label>
							<input type="submit" name="ifsc-get-details" value="Get Details" class="btn btn-primary" style="width: 100%;">
						</div>
					</div>
				</div>

			  	
				
			</div>
			<div class="col-md-6" id="bank-right-results" style="display: none;">
				<div class="card" >
					<div class="card-header" id="ifsc-bank-name" style="background: rgba(223,235,251,1);padding: 16px;">
						ABU DHABI COMMERCIAL BANK (ADCB0000001)
					</div>
					<div class="card-body" style="background: #fff; box-shadow: 24px 24px 24px 24px rgba(0,0,0,.13); -moz-box-shadow: 0 22px 24px 0 rgba(0,0,0,.13); padding: 16px;">
						
						<div class="row" style="font-size: 14px; padding-bottom: 10px;">
							<div class="col-md-3 text-left">
								<b>IFSC Code:</b>
							</div>
							<div class="col-md-9 text-left" style="padding: 0px;">
								<div id="ifsc-ifsc"></div>
							</div>
						</div>

						<div class="row" style="font-size: 14px;  padding-bottom: 10px;">
							<div class="col-md-3 text-left">
								<b>MICR Code:</b>
							</div>
							<div class="col-md-9 text-left" style="padding: 0px;">
								<div id="ifsc-micr"></div>
							</div>
						</div>

						<div class="row" style="font-size: 14px; padding-bottom: 10px;">
							<div class="col-md-3 text-left">
								<b>Address:</b>
							</div>
							<div class="col-md-9 text-left" style="padding: 0px;">
								<div id="ifsc-address"></div>
							</div>
						</div>

						<div class="row" style="font-size: 14px; padding-bottom: 10px;">
							<div class="col-md-3 text-left">
								<b>State:</b>
							</div>
							<div class="col-md-9 text-left" style="padding: 0px;">
								<div id="ifsc-state" style="color: #1b98e0;"></div>
							</div>
						</div>

						<div class="row" style="font-size: 14px; padding-bottom: 10px;">
							<div class="col-md-3 text-left">
								<b>City:</b>
							</div>
							<div class="col-md-9 text-left" style="padding: 0px;">
								<div id="ifsc-city" style="color: #1b98e0;"></div>
							</div>
						</div>
						<div class="row" style="font-size: 14px; padding-bottom: 10px;">
							<div class="col-md-3 text-left">
								<b>Branch:</b>
							</div>
							<div class="col-md-9 text-left" style="padding: 0px;">
								<div id="ifsc-branch" style="color: #1b98e0;"></div>
							</div>
						</div>

						<div class="row" style="font-size: 14px; padding-bottom: 10px;">
							<div class="col-md-3 text-left">
								<b>Contact:</b>
							</div>
							<div class="col-md-9 text-left" style="padding: 0px;">
								<div id="ifsc-contact"></div>
							</div>
						</div>


					</div>
				</div>	

			</div>
	  </div>

	  


	<p align="CENTER" style="margin-bottom: 0.11in; background: #0f3b68; padding: 6px; color: #fff;"><a name="_gjdgxs"></a>
		<b>WHAT IS IFSC CODE</b><p>
		<p style="margin-bottom: 0.11in">Indian Financial System Code or IFSC
		is a system of assigning the unique identification code to each
		branch of the bank participating in national electronic fund transfer
		system. There are more than 1,50,000 branches of different banks
		through length and breadth of the country. IFSC code is an 11 digit
		alphanumeric code which is unique and never repeated in the banking
		system.<p>
		<p style="margin-bottom: 0.11in">This code can be compared to the
		Aadhar number which is issued to individuals. As you all know that
		Aadhar number is a unique number and cannot be same for the any other
		individual in the country. 
	<p>
	<p align=CENTER style="margin-bottom: 0.11in; background: #0f3b68; padding: 6px; color: #fff;"><b>HOW
		IFSC WORKS</b><p>
		<p STYLE="margin-bottom: 0.11in">While making transfer of funds from
		one bank to another bank one just needs to select the IFSC code of
		the particular bank branch where the money needs to be transferred
		and the account number of the beneficiary. It is quite possible that
		in a large banking system (like Indian banking system) account number
		of two individuals maybe same in two different banks because every
		bank is free to issue any series of account numbers to its customers.
	<p>
	<p STYLE="margin-bottom: 0.11in">However, since IFSC code of the
		branch is always unique, when user selects IFSC code and the account
		number then it creates a unique combination for transfer of funds
		without error and to the right beneficiary. 
	<p>
	<p align=CENTER STYLE="margin-bottom: 0.11in; background: #0f3b68; padding: 6px; color: #fff;"><b>WHO
	ISSUES IFSC CODE</b></p>
	<p STYLE="margin-bottom: 0.11in">
		IFC quotes are assigned by RBI to
		all the banks’ branches participating in national electronic fund
		transfer system. 
	</p>
	<p align=CENTER STYLE="margin-bottom: 0.11in; background: #0f3b68; padding: 6px; color: #fff;"><b>HOW
	TO FIND IFSC CODE</b>
	</p>
	<p STYLE="margin-bottom: 0.11in">To find out the IFSC code of any
	particular bank branch user needs to select the following in the tool
	provided here in: 
	</p>
<ul>
	<li><p align="LEFT" STYLE="margin-bottom: 0in; background: #ffffff; border: none; padding: 0in; line-height: 107%; page-break-inside: auto; widows: 2; orphans: 2; page-break-after: auto">
	<span STYLE="font-variant: normal"><font COLOR="#000000"><span STYLE="text-decoration: none"><font FACE="Calibri, serif"><font SIZE=2 STYLE="font-size: 11pt"><span STYLE="font-style: normal"><span STYLE="font-weight: normal"><span STYLE="background: #ffffff">Bank
	name </span></span></span></font></font></span></font></span>
	</p>
	</li>	
	<li><p align="LEFT" STYLE="margin-bottom: 0in; background: #ffffff; border: none; padding: 0in; line-height: 107%; page-break-inside: auto; widows: 2; orphans: 2; page-break-after: auto">
	<span STYLE="font-variant: normal"><font COLOR="#000000"><span STYLE="text-decoration: none"><font FACE="Calibri, serif"><font SIZE=2 STYLE="font-size: 11pt"><span STYLE="font-style: normal"><span STYLE="font-weight: normal"><span STYLE="background: #ffffff">State
	name </span></span></span></font></font></span></font></span>
	</p>
	</li>	
	<li><p align="LEFT" STYLE="margin-bottom: 0in; background: #ffffff; border: none; padding: 0in; line-height: 107%; page-break-inside: auto; widows: 2; orphans: 2; page-break-after: auto">
	<span STYLE="font-variant: normal"><font COLOR="#000000"><span STYLE="text-decoration: none"><font FACE="Calibri, serif"><font SIZE=2 STYLE="font-size: 11pt"><span STYLE="font-style: normal"><span STYLE="font-weight: normal"><span STYLE="background: #ffffff">City
	name </span></span></span></font></font></span></font></span>
	</p>
	</li>	
	<li><p align="LEFT" STYLE="margin-bottom: 0.11in; background: #ffffff; border: none; padding: 0in; line-height: 107%; page-break-inside: auto; widows: 2; orphans: 2; page-break-after: auto">
	<span STYLE="font-variant: normal"><font COLOR="#000000"><span STYLE="text-decoration: none"><font FACE="Calibri, serif"><font SIZE=2 STYLE="font-size: 11pt"><span STYLE="font-style: normal"><span STYLE="font-weight: normal"><span STYLE="background: #ffffff">Branch
	name </span></span></span></font></font></span></font></span>
	</p>
	</li>	
</ul>
	<p STYLE="margin-bottom: 0.11in">On selection of these parameters the
	IFSC code will be displayed instantly. Alternatively if the user
	knows the IFSC code then he can fill it in the search box and know
	the details of the bank branch to ensure that he is transferring the
	money at the right branch. 
	</p>



         
      </div>
      <!-- /container -->
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.full.js"></script>
<script src="https://select2.github.io/select2-bootstrap-theme/js/bootstrap.min.js"></script>
<script src="https://select2.github.io/select2-bootstrap-theme/js/anchor.min.js"></script>

<script>
	anchors.options.placement = 'left';
	anchors.add('.container h1, .container h2, .container h3, .container h4, .container h5');
	$.fn.select2.defaults.set( "theme", "bootstrap" );
	
	$(".select2-bank" ).select2({placeholder: "Select a Bank"});
	$(".select2-state" ).select2({placeholder: "Select a State"});
	$(".select2-city" ).select2({placeholder: "Select a City"});
	$(".select2-branch" ).select2({placeholder: "Select a Branch"});



	$(document).ready(function(){
		
		$("select[name=ifsc-bank]" ).change(function() {
			$("select[name=ifsc-city]").html('<option value="">Select a City</option>');
			$("select[name=ifsc-branch]").html('<option value="">Select a Branch</option>');
			$("input[name=ifsc-code]").val("");
			$("#overlay").show();
			getState($(this).val());
		});
		function getState(bank){
			$("#bank-right-results").hide();
			$.ajax({
				url: 'https://www.visveya.com/vnabler.com/api/get-state/'+bank,
				type: 'get',
				dataType: 'json',
				async: false,
				beforeSend: function(){
					$("#overlay").show();
				},
				success: function(response){
					var html = '<option value="">Select a State</option>';
					for(var i=0; i<response.length; i++){
						html += '<option value="'+response[i].state_name+'">'+response[i].state_name+'</option>';
					}
					$("select[name=ifsc-state]").html(html);
				},
				complete:function(data){
					$("#overlay").hide();
				},
				error:function(data){
					$("#overlay").hide();
				}
			});
		}

		$("select[name=ifsc-state]").change(function() {
			$("select[name=ifsc-branch]").html('<option value="">Select a Branch</option>');
			$("input[name=ifsc-code]").val("");

			getCity($("select[name=ifsc-bank] option:selected").val(), $(this).val());
		});
		function getCity(bank, state){
			$("#bank-right-results").hide();
			$.ajax({
				url: 'https://www.visveya.com/vnabler.com/api/get-city/'+bank+'/'+state,
				type: 'get',
				dataType: 'json',
				beforeSend: function(){
					$("#overlay").show();
				},
				success: function(response){
					var html = '<option value="">Select a City</option>';
					for(var i=0; i<response.length; i++){
						html += '<option value="'+response[i].city_name+'">'+response[i].city_name+'</option>';
					}
					$("select[name=ifsc-city]").html(html);
				},
				complete:function(data){
					$("#overlay").hide();
				},
				error:function(data){
					$("#overlay").hide();
				}
			});
		}

		$("select[name=ifsc-city]").change(function() {
			$("input[name=ifsc-code]").val("");
			getBranch($("select[name=ifsc-bank] option:selected").val(), $("select[name=ifsc-state] option:selected").val(), $(this).val());
		});
		function getBranch(bank, state, city){
			$("#bank-right-results").hide();
			$.ajax({
				url: 'https://www.visveya.com/vnabler.com/api/get-branch/'+bank+'/'+state+'/'+city,
				type: 'get',
				dataType: 'json',
				beforeSend: function(){
					$("#overlay").show();
				},
				success: function(response){
					var html = '<option value="">Select a Branch</option>';
					for(var i=0; i<response.length; i++){
						html += '<option value="'+response[i].branch_name+'">'+response[i].branch_name+'</option>';
					}
					$("select[name=ifsc-branch]").html(html);
				},
				complete:function(data){
					$("#overlay").hide();
				},
				error:function(data){
					$("#overlay").hide();
				}
			});
		}

		$("select[name=ifsc-branch]").change(function() {
			getIfscDetails($("select[name=ifsc-bank] option:selected").val(), 
			$("select[name=ifsc-state] option:selected").val(), 
			$("select[name=ifsc-city] option:selected").val(), 
			$(this).val());
		});

		function getIfscDetails(bank, state, city, branch){
			$("#bank-right-results").hide();
			$.ajax({
				url: 'https://www.visveya.com/vnabler.com/api/get-bank-details/'+bank+'/'+state+'/'+city+'/'+branch,
				type: 'get',
				dataType: 'json',
				beforeSend: function(){
					$("#overlay").show();
				},
				success: function(response){
					$("input[name=ifsc-code]").val(response.bank_ifsc);
					$("#ifsc-bank-name").html(response.bank_name);

					$("#ifsc-ifsc").html('<a>'+response.bank_ifsc+'</a> (used for RTGS, IMPS and NEFT Transactions)');
					$("#ifsc-address").html(response.bank_address);
					$("#ifsc-state").html(response.state);
					$("#ifsc-city").html(response.city);
					$("#ifsc-branch").html(response.bank_branch);
					$("#ifsc-contact").html(response.bank_contact);

					$("#bank-right-results").show();
				},
				complete:function(data){
					$("#overlay").hide();
				},
				error:function(data){
					$("#overlay").hide();
				}
			});
		}

		$("input[name=ifsc-get-details]").click(function(){
			$("#bank-right-results").hide();
			$("#ifsc_error").hide();

			var ifsc = $("input[name=ifsc-code]").val();
			$.ajax({
				url: 'https://www.visveya.com/vnabler.com/api/get-bank-details-by-ifsc/'+ifsc,
				type: 'get',
				dataType: 'json',
				beforeSend: function(){
					$("#overlay").show();
				},
				success: function(response){
					if(response){
						$("#ifsc-bank-name").html(response.bank_name);

						$("input[name=ifsc-code]").val(response.bank_ifsc);
						$("#ifsc-ifsc").html('<a>'+response.bank_ifsc+'</a> (used for RTGS, IMPS and NEFT Transactions)');
						$("#ifsc-address").html(response.bank_address);
						$("#ifsc-state").html(response.state);
						$("#ifsc-city").html(response.city);
						$("#ifsc-branch").html(response.bank_branch);
						$("#ifsc-contact").html(response.bank_contact);

						$("select[name=ifsc-bank] option[value='"+response.bank_name+"']").prop("selected", "selected");
						$(".select2-bank" ).select2({placeholder: response.bank_name});

						$("select[name=ifsc-state]").html('<option value="'+response.state+'">'+response.state+'</option>');
						$("select[name=ifsc-state] option[value='"+response.state+"']").prop("selected", "selected");
						$(".select2-state" ).select2({placeholder: response.state});

						$("select[name=ifsc-city]").html('<option value="'+response.city+'">'+response.city+'</option>');
						$("select[name=ifsc-city] option[value='"+response.city+"']").prop("selected", "selected");
						$(".select2-city" ).select2({placeholder: response.city});

						$("select[name=ifsc-branch]").html('<option value="'+response.bank_branch+'">'+response.bank_branch+'</option>');
						$("select[name=ifsc-branch] option[value='"+response.branch+"']").prop("selected", "selected");
						$(".select2-branch" ).select2({placeholder: response.branch});

						$("#bank-right-results").show();
					}else{
						$("#ifsc_error").show();
					}
					
				},
				complete:function(data){
					$("#overlay").hide();
				},
				error:function(data){
					$("#overlay").hide();
				}
			});
		})
		$(".reset-details").click(function(){
			$("select[name=ifsc-bank]").val(null).trigger('change');
			$("select[name=ifsc-state]").html('<option value="">Select a State</option>');
			$("select[name=ifsc-city]").html('<option value="">Select a City</option>');
			$("select[name=ifsc-branch]").html('<option value="">Select a Branch</option>');
			$("input[name=ifsc-code]").val("");
			$("#bank-right-results").hide();
		})

	});



	
</script>

   </body>
</html>