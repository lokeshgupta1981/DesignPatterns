<div class="container pb-4">
    <div class="row mt-3">
    <div class="col-md-12">
        <h1>Fixed Deposit Calculator</h1>
        <p class="mt-3">Use this <strong>FD calculator</strong> to find the best possible return on your invested money, 
            by comparing quarterly compounding and simple interest (monthly or quarterly payouts) calculation options.</p>
            </div>
    </div>
    <div class="row mt-2">
    <div class="col-md-6">
        <div class="row">
        <div class="col-md-4 font-weight-bold">
            <label for="fdType">Type of FD</label>
        </div>
        <div class="col-md-7">
            <select class="form-control" id="fdType">
                <option value="0" selected>Reinvestment</option>
                <option value="1" pfactor="12">Payout - Monthly</option>
                <option value="2" pfactor="4">Payout - Quarterly</option>
            </select>
        </div>    
        </div>
        <div class="row mt-3">
        <div class="col-md-4 font-weight-bold">
            <label for="interestRate">Invested Amount</label>
        </div>
        <div class="col-md-7">
            <input type="number" class="form-control" id="investedAmount" value="100000">
        </div>    
        </div>
        <div class="row mt-3">
        <div class="col-md-4 font-weight-bold">
            <label for="interestRate">Interest Rate</label>
        </div>
        <div class="col-md-7">
            <input type="number" class="form-control" id="interestRate" value="6.5">
        </div>    
        </div>
        <div class="row mt-3">
        <div class="col-md-4 font-weight-bold">
            <label for="periodYrs">Period / Tenure</label>
        </div>
        <div class="col-md-8">
            <div class="input-group">
            <div class="input-group-prepend"><span class="input-group-text">YY</span></div>
            <select id="periodYrs" size="1">
                <option>0</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option selected>5</option>
                <option>6</option>
                <option>7</option>
                <option>8</option>
                <option>9</option>
                <option>10</option>
            </select>
            &nbsp;&nbsp;
            <div class="input-group-prepend"><span class="input-group-text">MM</span></div>
            <select id="periodMons" size="1">
                <option selected>0</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
                <option>6</option>
                <option>7</option>
                <option>8</option>
                <option>9</option>
                <option>10</option>
                <option>11</option>
            </select>
            &nbsp;&nbsp;
            <div class="input-group-prepend"><span class="input-group-text">DD</span></div>
            <input type="number" class="form-control col-2" maxlength="2" pattern="\d{2}" placeholder="0" id="periodDays" />
            </div>
        </div>   
        </div>
        <div class="row mt-3">
        <div class="col-md-12" style="padding-right: 50px !important;">
            <input type="button" id="calculateFD" value="CALCULATE" class="btn btn-warning font-weight-bold w-100"/>
        </div>
        </div>
    </div>
    <div class="col-md-6">
        <table class="table table-bordered table-success">
        <tbody>
            <tr>
            <td class="font-weight-bold" style="width: 50%;">Maturity Date</td>
            <td id="result0"></td>
            </tr>
            <tr>
            <td class="font-weight-bold" style="width: 50%;">Interest Rate</td>
            <td id="result1"></td>
            </tr>
            <tr>
            <td class="font-weight-bold">Maturity Amount</td>
            <td class="font-weight-bold" id="result2"></td> 
            </tr>
            <tr>
            <td class="font-weight-bold">Total Interest Earned</td>
            <td class="font-weight-bold" id="result3"></td>
            </tr>
        </tbody>
        </table>
        <p><em>Note: In India, banks use quarterly compounding to calculate interest in rupees.</em></p>
            </div>
    </div>

    <div class="row mt-4">
    <div class="col-md-12">
        <h3>Interest earned with other deposit options</h3>
    </div>
    <div class="col-md-6 mt-3">
        <table class="table table-hover table-info">
        <thead>
            <tr>
            <th>Reinvestment/Payouts</th>
            <th>Maturity Amount</th>
            </tr>
        </thead>
        <tbody id="otherOptions">
        </tbody>
        </table>
    </div>
    <div class="col-md-6 mt-3">
        <p>This table displays the interest earned in case monthly, quarterly, half-yearly, and yearly compounding is applied on invested amount.</p>
        <p><em>Simple interest</em> is earned in case when you select the periodic interest payment option. 
        E.g. quarterly payment option means that every quarter (90 days), the amount earned as interest will be paid to you. 
        In this way, the origonal invested amount does not get change or compound over time, and it remains same during whole investment period.</p>
    </div>
    </div>

    <div class="row mt-4">
    <div class="col-md-12">
        <h2>How to use the FD Calculator</h2>
        <p class="mt-4">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
    </div>
    </div>

    <div class="row mt-4">
    <div class="col-md-12">
        <h2>Discussion / Feedbacks</h2>
        <p  class="mt-4">Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
    </div>
    </div>

</div>