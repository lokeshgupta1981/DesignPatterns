$(function() {

    var factorArray = [1,2,4,12];

    $( "#calculateFD" ).click(function() 
    {
        var fdType = parseInt($("#fdType").children("option:selected").val());
        var investedAmount = parseFloat($("#investedAmount").val());
        var interestRate = parseFloat($("#interestRate").val());
        var periodYrs = parseInt($("#periodYrs").val());
        var periodMons = parseInt($("#periodMons").val());
        var periodDays = parseInt($("#periodDays").val() == "" ? 0 : $("#periodDays").val());
        var pfactor = parseInt($("#fdType").children("option:selected").attr("pfactor"));

        var today = new Date();
        var maturityDate = new Date();
        maturityDate = new Date(maturityDate.setDate(maturityDate.getDate() + periodDays));
        maturityDate = new Date(maturityDate.setMonth(maturityDate.getMonth() + periodMons));
        maturityDate = new Date(maturityDate.setFullYear(maturityDate.getFullYear() + periodYrs));

        var totalDays = date_diff_indays(today, maturityDate);

        var maturityAmount0 = reinvestmentAmountAndInterest(today, totalDays, investedAmount, interestRate);
        var maturityAmount1 = payoutAmountWithInterestMonthly(today, totalDays, investedAmount, interestRate);
        var maturityAmount2 = payoutAmountWithInterestQuarterly(today, totalDays, investedAmount, interestRate);

        $("#otherOptions").html("");

        if(fdType == 0)
        {
            $("#result0").html(maturityDate.toDateString());
            $("#result1").html(interestRate);
            $("#result2").html(formatAmt(maturityAmount0));
            $("#result3").html(formatAmt(maturityAmount0 - investedAmount));
            addRow("Interest Payout - Monthly", maturityAmount1);
            addRow("Interest Payout - Quarterly", maturityAmount2);
        }

        if(fdType == 1)
        {
            $("#result0").html(maturityDate.toDateString());
            $("#result1").html(interestRate);
            $("#result2").html(formatAmt(maturityAmount1));
            $("#result3").html(formatAmt(maturityAmount1 - investedAmount));
            addRow("Reinvestment", maturityAmount0);
            addRow("Interest Payout - Quarterly", maturityAmount2);
        }
        
        if(fdType == 2)
        {
            $("#result0").html(maturityDate.toDateString());
            $("#result1").html(interestRate);
            $("#result2").html(formatAmt(maturityAmount2));
            $("#result3").html(formatAmt(maturityAmount2 - investedAmount));
            addRow("Reinvestment", maturityAmount0);
            addRow("Interest Payout - Monthly", maturityAmount1);
        }
    });

    function payoutAmountWithInterestQuarterly(today, totalDays, investedAmount, interestRate)
    {
        var initialAnnualInterest = Math.round((investedAmount * interestRate ) / 100);
        var dailyInterest = initialAnnualInterest / days_of_a_year(today.getFullYear());
        var currentQuarter = quarter_of_the_year(today);
        var remainDayInCurrentQuarter = remainingDaysInCurrentQuarter(today, currentQuarter);

        var totalInterest = dailyInterest * remainDayInCurrentQuarter;
        var numberOfDays = totalDays - remainDayInCurrentQuarter;
        currentQuarter++;
        today = today.addDays(remainDayInCurrentQuarter);

        while(numberOfDays > 0)
        {
            dailyInterest = initialAnnualInterest / days_of_a_year(today.getFullYear());
            
            if(numberOfDays > 93)
            {
                remainDayInCurrentQuarter = daysInQuarter(currentQuarter % 4);
                today = today.addDays(remainDayInCurrentQuarter);
            }
            else
            {
                remainDayInCurrentQuarter = numberOfDays;
                today = today.addDays(remainDayInCurrentQuarter);
            }
            totalInterest = totalInterest + (dailyInterest * remainDayInCurrentQuarter);
            numberOfDays = numberOfDays - remainDayInCurrentQuarter;
            currentQuarter++;
        }

        return investedAmount + totalInterest;
    }

    function payoutAmountWithInterestMonthly(today, totalDays, investedAmount, interestRate)
    {
        var initialAnnualInterest = Math.round((investedAmount * interestRate ) / 100);
        var dailyInterest = initialAnnualInterest / days_of_a_year(today.getFullYear());
        var currentMonth = today.getMonth();
        var remainDayInCurrentMonth = new Date(today.getFullYear(), today.getMonth(), 0).getDay() - today.getDay();

        var totalInterest = dailyInterest * remainDayInCurrentMonth;
        var numberOfDays = totalDays - remainDayInCurrentMonth;
        currentMonth++;
        today = today.addDays(remainDayInCurrentMonth);

        while(numberOfDays > 0)
        {
            dailyInterest = initialAnnualInterest / days_of_a_year(today.getFullYear());
            
            if(numberOfDays > 31)
            {
                remainDayInCurrentMonth = today.getDate();
                today = today.addDays(remainDayInCurrentMonth);
            }
            else
            {
                remainDayInCurrentMonth = numberOfDays;
                today = today.addDays(remainDayInCurrentMonth);
            }
            totalInterest = totalInterest + (dailyInterest * remainDayInCurrentMonth);
            numberOfDays = numberOfDays - remainDayInCurrentMonth;
            currentMonth++;
        }

        return investedAmount + totalInterest;
    }

    function reinvestmentAmountAndInterest(today, totalDays, investedAmount, interestRate)
    {
        var initialAnnualInterest = Math.round((investedAmount * interestRate ) / 100);
        var dailyInterest = initialAnnualInterest / days_of_a_year(today.getFullYear());
        var currentQuarter = quarter_of_the_year(today);
        var remainDayInCurrentQuarter = remainingDaysInCurrentQuarter(today, currentQuarter);

        var totalAmountAfterCurrentQuarter = investedAmount + (dailyInterest * remainDayInCurrentQuarter);
        var numberOfDays = totalDays - remainDayInCurrentQuarter;
        currentQuarter++;
        today = today.addDays(remainDayInCurrentQuarter);

        while(numberOfDays > 0)
        {
            initialAnnualInterest = (totalAmountAfterCurrentQuarter * interestRate ) / 100;
            dailyInterest = initialAnnualInterest / days_of_a_year(today.getFullYear());
            
            if(numberOfDays > 93)
            {
                remainDayInCurrentQuarter = daysInQuarter(currentQuarter % 4);
                today = today.addDays(remainDayInCurrentQuarter);
            }
            else
            {
                remainDayInCurrentQuarter = numberOfDays;
                today = today.addDays(remainDayInCurrentQuarter);
            }
            
            totalAmountAfterCurrentQuarter = totalAmountAfterCurrentQuarter + (dailyInterest * remainDayInCurrentQuarter);
            numberOfDays = numberOfDays - remainDayInCurrentQuarter;
            currentQuarter++;
        }

        return totalAmountAfterCurrentQuarter;
    }

    function formatAmt(amt){
        return "&#8377; " + Math.round(amt).toLocaleString('en-IN');
    }

    function addRow( text, value)
    {
        $("#otherOptions").append('<tr><td>'+text+'</td><td>'+"&#8377; " + Math.round(value).toLocaleString('en-IN')+'</td></tr>');
    }

    function quarter_of_the_year(date) 
    {
        var month = date.getMonth() + 1;
        return (Math.ceil(month / 3));
    }

    function remainingDaysInCurrentQuarter(date, quarter) 
    {
        if(quarter == 1) {return date_diff_indays(date, new Date(date.getFullYear(), 2, 31))} 
        if(quarter == 2) {return date_diff_indays(date, new Date(date.getFullYear(), 5, 30))}
        if(quarter == 3) {return date_diff_indays(date, new Date(date.getFullYear(), 8, 30))} 
        if(quarter == 4) {return date_diff_indays(date, new Date(date.getFullYear(), 11, 31))} 
    }

    function daysInQuarter(quarter) 
    {
        if(quarter == 1) {return 90;} 
        if(quarter == 2) {return 91;} 
        if(quarter == 3) {return 92;} 
        if(quarter == 4 || quarter == 0) {return 93;} 
    }

    function date_diff_indays (date1, date2) {
        dt1 = new Date(date1);
        dt2 = new Date(date2);
        return Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate()) ) /(1000 * 60 * 60 * 24));
    }

    Date.prototype.addDays = function(days) {
        var date = new Date(this.valueOf());
        date.setDate(date.getDate() + days);
        return date;
    }   
    
    function days_of_a_year(year) 
    {
        return isLeapYear(year) ? 366 : 365;
    }

    function isLeapYear(year) {
        return year % 400 === 0 || (year % 100 !== 0 && year % 4 === 0);
    }

    $( "#calculateFD" ).click();
});