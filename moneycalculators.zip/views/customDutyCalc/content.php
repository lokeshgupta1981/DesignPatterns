<div class="container pb-4">
    <div class="row mt-3">
    <div class="col-md-12">
        <h1>Online Custom Duty Calculator</h1>
        <p class="mt-3">Use this custom duty calculator to .....</p>
            </div>
    </div>
    <div class="row mt-2">
        <div class="col-md-6">
            <div class="row mt-3">
                <div class="col-md-5 font-weight-bold">
                    <label for="fdType">Value of Goods</label>
                </div>
                <div class="col-md-6">
                    <input type="number" class="form-control" id="valueOfGoods" value="1000">
                </div>    
            </div>
            <div class="row mt-3">
                <div class="col-md-5 font-weight-bold">
                    <label for="interestRate">Custom Duty (%)</label>
                </div>
                <div class="col-md-6">
                    <input type="number" class="form-control" id="dutyPercentage" value="5">
                </div>    
            </div>
            <div class="row mt-3">
                <div class="col-md-5 font-weight-bold">
                    <label for="interestRate">Welfare Surcharge (%)</label>
                </div>
                <div class="col-md-6">
                    <input type="number" class="form-control" id="socialCharge" value="10">
                </div>    
            </div>
            <div class="row mt-3">
                <div class="col-md-5 font-weight-bold">
                    <label for="interestRate">IGST (%)</label>
                </div>
                <div class="col-md-6">
                    <select class="form-control" id="igstPercentage">
                        <option value="0">0</option>
                        <option value="5" selected>5</option>
                        <option value="12">12</option>
                        <option value="18">18</option>
                        <option value="28">28</option>
                    </select>
                </div>    
            </div>
            <div class="row mt-3">
                <div class="col-md-5 font-weight-bold">
                    <label for="interestRate">Compensation Cess</label>
                </div>
                <div class="col-md-6">
                    <select class="form-control" id="cessPercentage">
                        <option value="0" selected>0</option>
                        <option value="1">1</option>
                    </select>
                </div>    
            </div>

            <div class="row mt-4 pt-4">
                <div class="col-md-12" style="padding-right: 50px !important;">
                    <input type="button" id="calculateDuty" value="CALCULATE" class="btn btn-warning font-weight-bold w-100"/>
                </div>
            </div>
        </div>
        <div class="col-md-6 mt-3">
            <table class="table table-bordered table-success">
            <tbody>
                <tr>
                    <td class="font-weight-bold bg-dark text-light" colspan="2">Calculation / Break Up</td>
                </tr>
                <tr>
                    <td class="font-weight-bold" style="width: 50%;">Custom Duty</td>
                    <td id="result1"></td>
                </tr>
                <tr>
                    <td class="font-weight-bold" style="width: 50%;">Social Welfare Charge</td>
                    <td id="result2"></td>
                </tr>
                <tr>
                    <td class="font-weight-bold" style="width: 50%;">IGST</td>
                    <td id="result3"></td>
                </tr>
                <tr>
                    <td class="font-weight-bold" style="width: 50%;">Cess</td>
                    <td id="result4"></td>
                </tr>
                <tr>
                    <td class="font-weight-bold" style="width: 50%;">Total Custom Duty</td>
                    <td id="result5" class="font-weight-bold"></td>
                </tr>
                <tr>
                    <td class="font-weight-bold" style="width: 50%;">Total Value of Imports</td>
                    <td id="result6" class="font-weight-bold"></td>
                </tr>
            </tbody>
            </table>    
        </div>
    </div>

    <div class="row mt-4">
    <div class="col-md-12">
        <h2>How to use custom duty calculator</h2>
        <p class="mt-4">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
    </div>
    </div>

    <div class="row mt-4">
    <div class="col-md-12">
        <h2>Discussion / Feedbacks</h2>
        <p  class="mt-4">Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
    </div>
    </div>

</div>