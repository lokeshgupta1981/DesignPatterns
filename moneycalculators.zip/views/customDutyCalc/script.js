$(function() {
    $( "#calculateDuty" ).click(function() 
    {
        var valueOfGoods = parseFloat($("#valueOfGoods").val());
        var dutyPercentage = parseFloat($("#dutyPercentage").val());
        var socialCharge = parseFloat($("#socialCharge").val());
        var igstPercentage = parseInt($("#igstPercentage").val());
        var cessPercentage = parseInt($("#cessPercentage").val());

        var customDuty = (valueOfGoods * dutyPercentage) / 100;
        var surcharge = (customDuty * socialCharge) / 100;
        var iGST = ((valueOfGoods + customDuty + surcharge) * igstPercentage) / 100;
        var compCess = (iGST * cessPercentage) / 100;
        var totalDuty = customDuty + surcharge + iGST + compCess;
        var totalImportValue = valueOfGoods + totalDuty;

        $("#result1").html(formatAmt(customDuty));
        $("#result2").html(formatAmt(surcharge));
        $("#result3").html(formatAmt(iGST));
        $("#result4").html(formatAmt(compCess));
        $("#result5").html(formatAmt(totalDuty));
        $("#result6").html(formatAmt(totalImportValue));
    });

    function formatAmt(amt){
        return "&#8377; " + amt;
    }

    $( "#calculateDuty" ).click();
});